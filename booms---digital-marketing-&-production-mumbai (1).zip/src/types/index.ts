export interface PortfolioProject {
  id: string;
  title: string;
  client: string;
  category: string;
  year: string;
  image: string;
  tagline: string;
  description: string;
  metrics: {
    label: string;
    value: string;
  }[];
  deliverables: string[];
  director: string;
  location: string;
  accentColor: string;
  duration: string;
  type?: 'video' | 'link' | 'image' | 'instagram';
  videoUrl?: string;
  youtubeId?: string;
}

export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  description: string;
  capabilities: string[];
  deliverableMetric: string;
}

export interface ContactFormData {
  fullName: string;
  email: string;
  phone: string;
  companyName: string;
  serviceType: string;
  budgetRange: string;
  message: string;
}

export interface RoiEstimate {
  estimatedImpressions: number;
  projectedLeads: number;
  estimatedRoas: number;
  productionTimelineWeeks: number;
  recommendedMix: string[];
}

export interface InstagramFeedItem {
  id: string;
  clientName: string;
  instagramHandle: string;
  postUrl: string;
  mediaType: 'reel' | 'post' | 'carousel';
  caption: string;
  viewsCount?: string;
  likesCount?: string;
  commentsCount?: string;
  thumbnailUrl: string;
  tags: string[];
  publishedDate: string;
}

export interface LeadItem {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  companyName: string;
  serviceType: string;
  budgetRange: string;
  message: string;
  createdAt: string;
  status: 'new' | 'contacted' | 'proposal_sent' | 'closed';
}

export interface ClientTestimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  quote: string;
  rating: number;
  metric: string;
  category: string;
  avatar: string;
  projectTitle?: string;
  verified: boolean;
  createdAt: string;
}

export interface CrmPaymentRecord {
  id: string;
  amount: number;
  date: string;
  method: 'UPI' | 'NEFT/RTGS' | 'Razorpay' | 'Cheque';
  referenceNo: string;
  note?: string;
}

export interface FormulaSnapshot {
  id: string;
  createdAt: string;
  type: 'Digital Marketing' | 'Social Media' | 'Video Production';
  summary: string;
  metrics: Record<string, string | number>;
}

export interface CrmClient {
  id: string;
  clientName: string;
  companyName: string;
  phone: string;
  email: string;
  gstNumber?: string;
  servicePackage:
    | 'Digital Marketing & Performance Ads'
    | 'Social Media Management & Reels'
    | 'Commercial Video Production'
    | '360° Full Studio Retainer';
  projectStatus: 'Onboarding' | 'Active Campaign' | 'In Production' | 'Completed';
  totalContractValue: number;
  paidAmount: number;
  pendingAmount: number;
  gstAmount: number;
  paymentStatus: 'Paid' | 'Partial' | 'Pending' | 'Overdue';
  dueDate: string;
  assignedLead: string;
  deliverablesSummary: string;
  payments: CrmPaymentRecord[];
  formulaSnapshots: FormulaSnapshot[];
  createdAt: string;
}

export interface DigitalMarketingFormulaResult {
  roas: number;
  roiPercent: number;
  cpa: number;
  cpm: number;
  cpc: number;
  ctrPercent: number;
  cvrPercent: number;
  ltvValue: number;
  ltvToCacRatio: number;
}

export interface SocialMediaFormulaResult {
  engagementRateByFollowers: number;
  engagementRateByReach: number;
  viralCoefficientK: number;
  hookRate3Sec: number;
  holdRateCompletion: number;
  monthlyFollowerGrowthRate: number;
  estimatedOrganicImpressions: number;
}

export interface ProductionFormulaResult {
  preProductionCost: number;
  shootDaysTotalCost: number;
  postProductionCost: number;
  baseProductionCost: number;
  agencyMarginAmount: number;
  subtotalBeforeGst: number;
  gstAmount18: number;
  grandTotalWithGst: number;
  costPerFinishedMinute: number;
  costPerViralReel: number;
  studioUtilizationRate: number;
}



