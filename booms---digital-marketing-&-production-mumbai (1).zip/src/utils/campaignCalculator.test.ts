import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateRoiEstimate,
  getProjectIndex,
  validateContactForm,
  formatINR,
  validateTestimonialForm,
  calculateAverageRating,
  calculateDigitalMarketingFormulas,
  calculateSocialMediaFormulas,
  calculateProductionFormulas,
  calculateClientPaymentStatus,
} from './campaignCalculator';

test('getProjectIndex wraps forward and backward safely', () => {
  const total = 4;
  assert.equal(getProjectIndex(0, 1, total), 1);
  assert.equal(getProjectIndex(3, 1, total), 0);
  assert.equal(getProjectIndex(0, -1, total), 3);
  assert.equal(getProjectIndex(2, -1, total), 1);
  assert.equal(getProjectIndex(0, 0, 0), 0);
});

test('calculateRoiEstimate yields scalable metrics and timeline', () => {
  const estimate = calculateRoiEstimate(100000, 'video-ad-production');
  assert.ok(estimate.estimatedImpressions > 0);
  assert.ok(estimate.projectedLeads >= 10);
  assert.ok(estimate.estimatedRoas >= 4.0);
  assert.equal(estimate.productionTimelineWeeks, 4);
  assert.ok(estimate.recommendedMix.length >= 3);
});

test('validateContactForm checks required fields strictly', () => {
  const invalid = validateContactForm({
    fullName: '',
    email: 'not-an-email',
    phone: '123',
  });
  assert.equal(invalid.isValid, false);
  assert.ok(invalid.errors.fullName);
  assert.ok(invalid.errors.email);
  assert.ok(invalid.errors.phone);

  const valid = validateContactForm({
    fullName: 'Rahul Sharma',
    email: 'rahul@brand.com',
    phone: '8006603090',
    serviceType: 'video-ad-production',
  });
  assert.equal(valid.isValid, true);
  assert.equal(Object.keys(valid.errors).length, 0);
});

test('formatINR formats currency properly', () => {
  const str = formatINR(500000);
  assert.ok(str.includes('5,00,000') || str.includes('500,000'));
});

test('validateTestimonialForm checks client name, company, and quote length', () => {
  const invalid = validateTestimonialForm({
    name: '',
    company: 'A',
    quote: 'Too short',
  });
  assert.equal(invalid.isValid, false);
  assert.ok(invalid.errors.name);
  assert.ok(invalid.errors.company);
  assert.ok(invalid.errors.quote);

  const valid = validateTestimonialForm({
    name: 'Nitin Gupta',
    company: 'TIFL',
    quote: 'Exceptional video production and digital strategy!',
    rating: 5,
  });
  assert.equal(valid.isValid, true);
  assert.equal(Object.keys(valid.errors).length, 0);
});

test('calculateAverageRating computes rounded average accurately', () => {
  assert.equal(calculateAverageRating([]), 5.0);
  assert.equal(calculateAverageRating([{ rating: 5 }, { rating: 4 }]), 4.5);
  assert.equal(calculateAverageRating([{ rating: 5 }, { rating: 5 }, { rating: 5 }]), 5.0);
});

test('calculateDigitalMarketingFormulas computes ROAS, ROI, CPA, CPM, CPC, CTR, CVR, and LTV:CAC', () => {
  const res = calculateDigitalMarketingFormulas({
    adSpend: 200000,
    revenueGenerated: 960000,
    impressions: 1000000,
    clicks: 25000,
    conversions: 500,
    avgOrderValue: 2400,
    repeatPurchaseFrequency: 3,
    grossMarginPercent: 60,
  });
  assert.equal(res.roas, 4.8);
  assert.equal(res.roiPercent, 380);
  assert.equal(res.cpa, 400);
  assert.equal(res.cpm, 200);
  assert.equal(res.cpc, 8);
  assert.equal(res.ctrPercent, 2.5);
  assert.equal(res.cvrPercent, 2);
  assert.equal(res.ltvValue, 4320);
  assert.equal(res.ltvToCacRatio, 10.8);
});

test('calculateSocialMediaFormulas computes ER, Hook Rate, Hold Rate, and Viral K-Factor', () => {
  const res = calculateSocialMediaFormulas({
    followers: 50000,
    reach: 200000,
    impressions: 300000,
    likes: 12000,
    comments: 800,
    shares: 3200,
    saves: 4000,
    threeSecViews: 120000,
    fullVideoWatches: 48000,
    netNewFollowers: 2500,
  });
  assert.equal(res.engagementRateByFollowers, 40);
  assert.equal(res.engagementRateByReach, 10);
  assert.equal(res.hookRate3Sec, 40);
  assert.equal(res.holdRateCompletion, 40);
  assert.equal(res.monthlyFollowerGrowthRate, 5);
  assert.ok(res.estimatedOrganicImpressions > 300000);
});

test('calculateProductionFormulas computes studio costs, margin, 18% GST, and cost per reel', () => {
  const res = calculateProductionFormulas({
    preProductionCost: 50000,
    shootDays: 2,
    cameraGearDailyRate: 40000,
    soundstageDailyRate: 35000,
    crewDailyRate: 25000,
    editingVfxCost: 30000,
    colorGradingSoundCost: 20000,
    agencyMarginPercent: 20,
    totalFinishedMinutes: 3,
    deliverablesReelsCount: 10,
  });
  assert.equal(res.shootDaysTotalCost, 200000);
  assert.equal(res.postProductionCost, 50000);
  assert.equal(res.baseProductionCost, 300000);
  assert.equal(res.agencyMarginAmount, 60000);
  assert.equal(res.subtotalBeforeGst, 360000);
  assert.equal(res.gstAmount18, 64800);
  assert.equal(res.grandTotalWithGst, 424800);
  assert.equal(res.costPerViralReel, 42480);
});

test('calculateClientPaymentStatus computes pending balance, GST, and Paid/Partial/Pending status', () => {
  const partial = calculateClientPaymentStatus(500000, 300000);
  assert.equal(partial.pendingAmount, 200000);
  assert.equal(partial.gstAmount, 90000);
  assert.equal(partial.paymentStatus, 'Partial');

  const paid = calculateClientPaymentStatus(500000, 500000);
  assert.equal(paid.pendingAmount, 0);
  assert.equal(paid.paymentStatus, 'Paid');

  const pending = calculateClientPaymentStatus(500000, 0);
  assert.equal(pending.pendingAmount, 500000);
  assert.equal(pending.paymentStatus, 'Pending');
});


