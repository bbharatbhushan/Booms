import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { CrmClient, LeadItem } from '../types';

export const SCOPES = ['https://www.googleapis.com/auth/spreadsheets'];

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);

const provider = new GoogleAuthProvider();
SCOPES.forEach((scope) => provider.addScope(scope));

// Flag to indicate if we are in the middle of a sign-in flow.
let isSigningIn = false;
// Cache the access token in memory ONLY (never in localStorage or sessionStorage).
let cachedAccessToken: string | null = null;

export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        cachedAccessToken = null;
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to get access token from Firebase Auth');
    }

    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Sign in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

export const logoutGoogle = async () => {
  await auth.signOut();
  cachedAccessToken = null;
};

export interface ReportExportPayload {
  clients: CrmClient[];
  leads: LeadItem[];
  formulaMetrics: {
    category: string;
    metricName: string;
    formulaUsed: string;
    calculatedValue: string;
  }[];
}

/**
 * Creates a new multi-tab Google Spreadsheet in the user's Google account
 * and writes CRM Clients, Payments, Formula Benchmarks, and Leads into it.
 */
export async function exportReportToGoogleSheets(
  accessToken: string,
  payload: ReportExportPayload
): Promise<{ spreadsheetId: string; spreadsheetUrl: string; title: string }> {
  const dateStr = new Date().toISOString().slice(0, 10);
  const title = `Booms Admin CRM, Payments & Formula Report (${dateStr})`;

  // 1. Create the spreadsheet with 3 structured sheets
  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: { title },
      sheets: [
        { properties: { title: 'Clients & Payments CRM' } },
        { properties: { title: 'Marketing & Production Formulas' } },
        { properties: { title: 'Website Inquiries & Leads' } },
      ],
    }),
  });

  if (!createRes.ok) {
    const errText = await createRes.text();
    throw new Error(`Failed to create Google Sheet: ${errText}`);
  }

  const createdSheet = await createRes.json();
  const spreadsheetId: string = createdSheet.spreadsheetId;
  const spreadsheetUrl: string =
    createdSheet.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

  // 2. Prepare tabular values for each sheet
  const clientRows = [
    [
      'Client ID',
      'Client Name',
      'Company / Brand',
      'Mobile Phone',
      'Email',
      'GSTIN',
      'Service Package',
      'Project Status',
      'Contract Value (INR)',
      'Amount Paid (INR)',
      'Pending Balance (INR)',
      '18% GST (INR)',
      'Payment Status',
      'Due Date',
      'Assigned Lead',
      'Deliverables',
    ],
    ...payload.clients.map((c) => [
      c.id,
      c.clientName,
      c.companyName,
      c.phone,
      c.email,
      c.gstNumber || 'N/A',
      c.servicePackage,
      c.projectStatus,
      c.totalContractValue,
      c.paidAmount,
      c.pendingAmount,
      c.gstAmount,
      c.paymentStatus,
      c.dueDate,
      c.assignedLead,
      c.deliverablesSummary,
    ]),
  ];

  const formulaRows = [
    ['Discipline', 'KPI / Metric Name', 'Standard Formula', 'Live Calculated Value'],
    ...payload.formulaMetrics.map((f) => [
      f.category,
      f.metricName,
      f.formulaUsed,
      f.calculatedValue,
    ]),
  ];

  const leadRows = [
    ['Lead ID', 'Full Name', 'Company', 'Phone', 'Email', 'Service Type', 'Budget Range', 'Status', 'Created At', 'Notes'],
    ...payload.leads.map((l) => [
      l.id,
      l.fullName,
      l.companyName,
      l.phone,
      l.email,
      l.serviceType,
      l.budgetRange,
      l.status,
      l.createdAt,
      l.message,
    ]),
  ];

  // 3. Batch update values across the 3 tabs
  const batchRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchUpdate`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        valueInputOption: 'USER_ENTERED',
        data: [
          {
            range: "'Clients & Payments CRM'!A1",
            values: clientRows,
          },
          {
            range: "'Marketing & Production Formulas'!A1",
            values: formulaRows,
          },
          {
            range: "'Website Inquiries & Leads'!A1",
            values: leadRows,
          },
        ],
      }),
    }
  );

  if (!batchRes.ok) {
    const errText = await batchRes.text();
    throw new Error(`Created sheet, but failed to write rows: ${errText}`);
  }

  return { spreadsheetId, spreadsheetUrl, title };
}

/**
 * Generates and downloads a Google-Sheets-ready CSV file containing
 * Client CRM, Payment Balances, and Digital Marketing / Production Formulas.
 */
export function downloadReportCsv(payload: ReportExportPayload) {
  const escapeCsv = (val: unknown) => {
    const str = String(val ?? '');
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  const lines: string[] = [];

  lines.push('=== BOOMS ADMIN CRM: CLIENTS & PAYMENT LEDGER ===');
  lines.push(
    [
      'Client ID',
      'Client Name',
      'Company / Brand',
      'Phone',
      'Email',
      'GSTIN',
      'Service Package',
      'Project Status',
      'Contract Value (INR)',
      'Paid Amount (INR)',
      'Pending Amount (INR)',
      '18% GST (INR)',
      'Payment Status',
      'Due Date',
      'Assigned Lead',
      'Deliverables',
    ]
      .map(escapeCsv)
      .join(',')
  );

  payload.clients.forEach((c) => {
    lines.push(
      [
        c.id,
        c.clientName,
        c.companyName,
        c.phone,
        c.email,
        c.gstNumber || 'N/A',
        c.servicePackage,
        c.projectStatus,
        c.totalContractValue,
        c.paidAmount,
        c.pendingAmount,
        c.gstAmount,
        c.paymentStatus,
        c.dueDate,
        c.assignedLead,
        c.deliverablesSummary,
      ]
        .map(escapeCsv)
        .join(',')
    );
  });

  lines.push('');
  lines.push('=== DIGITAL MARKETING, SOCIAL MEDIA & PRODUCTION FORMULA SUITE ===');
  lines.push(['Discipline', 'KPI / Metric', 'Formula', 'Calculated Value'].map(escapeCsv).join(','));
  payload.formulaMetrics.forEach((f) => {
    lines.push([f.category, f.metricName, f.formulaUsed, f.calculatedValue].map(escapeCsv).join(','));
  });

  lines.push('');
  lines.push('=== WEBSITE INQUIRIES & LEADS ===');
  lines.push(
    ['Lead ID', 'Full Name', 'Company', 'Phone', 'Email', 'Service', 'Budget', 'Status', 'Message']
      .map(escapeCsv)
      .join(',')
  );
  payload.leads.forEach((l) => {
    lines.push(
      [
        l.id,
        l.fullName,
        l.companyName,
        l.phone,
        l.email,
        l.serviceType,
        l.budgetRange,
        l.status,
        l.message,
      ]
        .map(escapeCsv)
        .join(',')
    );
  });

  const csvContent = '\uFEFF' + lines.join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `Booms_CRM_Payments_Formulas_Report_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
