import {
  ContactFormData,
  RoiEstimate,
  DigitalMarketingFormulaResult,
  SocialMediaFormulaResult,
  ProductionFormulaResult,
} from '../types';

/**
 * Calculates estimated campaign reach, ROAS, and deliverables based on monthly budget and service focus.
 */
export function calculateRoiEstimate(monthlyBudget: number, serviceType: string): RoiEstimate {
  const budget = Math.max(25000, monthlyBudget);

  let cpm = 180; // Cost per 1000 impressions in INR
  let baseRoas = 3.8;
  let timelineWeeks = 3;
  let recommendedMix = ['Instagram Reels', 'Meta Feed Ads', 'Story Retargeting'];

  switch (serviceType) {
    case 'video-ad-production':
      cpm = 240;
      baseRoas = 4.5;
      timelineWeeks = 4;
      recommendedMix = ['Cinema Commercial Film', '4K Vertical Reels', 'YouTube Pre-Roll Ads', 'UGC Creator Drops'];
      break;
    case 'performance-marketing':
      cpm = 150;
      baseRoas = 5.2;
      timelineWeeks = 2;
      recommendedMix = ['Meta Performance Scaling', 'Google Search & PMax', 'High-Converting Landing Pages', 'DCO Dynamic Creative'];
      break;
    case 'influencer-creator-lab':
      cpm = 210;
      baseRoas = 4.1;
      timelineWeeks = 3;
      recommendedMix = ['Mumbai Macro Creator Drops', 'Hyper-Local Micro Influencers', 'Whitelisted Spark Ads', 'Affiliate Tracking'];
      break;
    case 'social-media-management':
    default:
      cpm = 160;
      baseRoas = 3.9;
      timelineWeeks = 3;
      recommendedMix = ['Daily Content Production', 'Reels Algorithm Strategy', 'Community DM Automation', 'Viral Trend Seeding'];
      break;
  }

  // Budget scaling bonus
  if (budget >= 500000) {
    baseRoas += 0.6;
  } else if (budget >= 200000) {
    baseRoas += 0.3;
  }

  const estimatedImpressions = Math.round((budget / cpm) * 1000);
  const clickThroughRate = 0.022; // 2.2%
  const conversionRate = 0.038; // 3.8%
  const projectedLeads = Math.max(12, Math.round(estimatedImpressions * clickThroughRate * conversionRate));

  return {
    estimatedImpressions,
    projectedLeads,
    estimatedRoas: Math.round(baseRoas * 10) / 10,
    productionTimelineWeeks: timelineWeeks,
    recommendedMix,
  };
}

/**
 * Safe circular navigation helper for the 3D player next / prev buttons.
 */
export function getProjectIndex(currentIndex: number, delta: number, total: number): number {
  if (total <= 0) return 0;
  const next = (currentIndex + delta) % total;
  return next < 0 ? next + total : next;
}

/**
 * Validates the contact form fields.
 */
export function validateContactForm(data: Partial<ContactFormData>): { isValid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};

  if (!data.fullName || data.fullName.trim().length < 2) {
    errors.fullName = 'Please enter your full name.';
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!data.email || !emailRegex.test(data.email.trim())) {
    errors.email = 'Please provide a valid business email address.';
  }

  // Clean phone input and check for minimum 10 digits (e.g. 8006603090)
  const phoneClean = (data.phone || '').replace(/[^\d]/g, '');
  if (!data.phone || phoneClean.length < 10) {
    errors.phone = 'Please provide a 10-digit mobile number.';
  }

  if (!data.serviceType) {
    errors.serviceType = 'Please select a primary service.';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}

/**
 * Formats a number to Indian Rupee standard format (e.g. ₹5,00,000).
 */
export function formatINR(val: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(val);
}

/**
 * Validates a new client testimonial submission.
 */
export function validateTestimonialForm(data: {
  name?: string;
  company?: string;
  quote?: string;
  rating?: number;
}): { isValid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};

  if (!data.name || data.name.trim().length < 2) {
    errors.name = 'Please enter the client name.';
  }

  if (!data.company || data.company.trim().length < 2) {
    errors.company = 'Please enter the company or brand name.';
  }

  if (!data.quote || data.quote.trim().length < 10) {
    errors.quote = 'Please provide a review of at least 10 characters.';
  }

  if (data.rating !== undefined && (data.rating < 1 || data.rating > 5)) {
    errors.rating = 'Rating must be between 1 and 5.';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}

/**
 * Computes average rating across a list of testimonials.
 */
export function calculateAverageRating(items: { rating: number }[]): number {
  if (!items || items.length === 0) return 5.0;
  const sum = items.reduce((acc, item) => acc + (Number(item.rating) || 5), 0);
  return Math.round((sum / items.length) * 10) / 10;
}

/**
 * 1. Digital Marketing & Paid Ads Formula Suite
 * Computes ROAS, ROI%, CPA/CAC, CPM, CPC, CTR%, CVR%, LTV, and LTV:CAC ratio.
 */
export function calculateDigitalMarketingFormulas(input: {
  adSpend: number;
  revenueGenerated: number;
  impressions: number;
  clicks: number;
  conversions: number;
  avgOrderValue: number;
  repeatPurchaseFrequency: number;
  grossMarginPercent: number;
}): DigitalMarketingFormulaResult {
  const spend = Math.max(1, input.adSpend);
  const rev = Math.max(0, input.revenueGenerated);
  const imp = Math.max(1, input.impressions);
  const clk = Math.max(1, input.clicks);
  const conv = Math.max(1, input.conversions);

  const roas = Math.round((rev / spend) * 100) / 100;
  const roiPercent = Math.round(((rev - spend) / spend) * 1000) / 10;
  const cpa = Math.round(spend / conv);
  const cpm = Math.round((spend / imp) * 1000);
  const cpc = Math.round((spend / clk) * 10) / 10;
  const ctrPercent = Math.round((clk / imp) * 10000) / 100;
  const cvrPercent = Math.round((conv / clk) * 10000) / 100;
  const ltvValue = Math.round(
    input.avgOrderValue * input.repeatPurchaseFrequency * (input.grossMarginPercent / 100)
  );
  const ltvToCacRatio = Math.round((ltvValue / Math.max(1, cpa)) * 10) / 10;

  return {
    roas,
    roiPercent,
    cpa,
    cpm,
    cpc,
    ctrPercent,
    cvrPercent,
    ltvValue,
    ltvToCacRatio,
  };
}

/**
 * 2. Social Media Management & Viral Reels Formula Suite
 * Computes Engagement Rate (Followers & Reach), Hook Rate (3s), Hold Rate, Viral K-Factor, and Follower Growth %.
 */
export function calculateSocialMediaFormulas(input: {
  followers: number;
  reach: number;
  impressions: number;
  likes: number;
  comments: number;
  shares: number;
  saves: number;
  threeSecViews: number;
  fullVideoWatches: number;
  netNewFollowers: number;
}): SocialMediaFormulaResult {
  const totalEngagements =
    Math.max(0, input.likes) +
    Math.max(0, input.comments) +
    Math.max(0, input.shares) +
    Math.max(0, input.saves);
  const fol = Math.max(1, input.followers);
  const rch = Math.max(1, input.reach);
  const imp = Math.max(1, input.impressions);
  const v3s = Math.max(1, input.threeSecViews);

  const engagementRateByFollowers = Math.round((totalEngagements / fol) * 10000) / 100;
  const engagementRateByReach = Math.round((totalEngagements / rch) * 10000) / 100;
  const hookRate3Sec = Math.round((input.threeSecViews / imp) * 10000) / 100;
  const holdRateCompletion = Math.round((input.fullVideoWatches / v3s) * 10000) / 100;
  const monthlyFollowerGrowthRate = Math.round((input.netNewFollowers / fol) * 10000) / 100;
  const viralCoefficientK =
    Math.round(((input.shares / rch) * (1 + input.saves / rch) * 12) * 100) / 100;
  const estimatedOrganicImpressions = Math.round(imp + input.shares * 18 + input.saves * 9);

  return {
    engagementRateByFollowers,
    engagementRateByReach,
    viralCoefficientK,
    hookRate3Sec,
    holdRateCompletion,
    monthlyFollowerGrowthRate,
    estimatedOrganicImpressions,
  };
}

/**
 * 3. Commercial Video & Cinema Production Formula Suite
 * Computes Pre-Production, Shoot Days Cost, Post-Production, Agency Margin, 18% GST, Cost per Reel, and Cost per Minute.
 */
export function calculateProductionFormulas(input: {
  preProductionCost: number;
  shootDays: number;
  cameraGearDailyRate: number;
  soundstageDailyRate: number;
  crewDailyRate: number;
  editingVfxCost: number;
  colorGradingSoundCost: number;
  agencyMarginPercent: number;
  totalFinishedMinutes: number;
  deliverablesReelsCount: number;
}): ProductionFormulaResult {
  const preProd = Math.max(0, input.preProductionCost);
  const days = Math.max(1, input.shootDays);
  const dailyBurn =
    Math.max(0, input.cameraGearDailyRate) +
    Math.max(0, input.soundstageDailyRate) +
    Math.max(0, input.crewDailyRate);
  const shootDaysTotalCost = days * dailyBurn;
  const postProductionCost = Math.max(0, input.editingVfxCost) + Math.max(0, input.colorGradingSoundCost);
  const baseProductionCost = preProd + shootDaysTotalCost + postProductionCost;
  const agencyMarginAmount = Math.round(baseProductionCost * (Math.max(0, input.agencyMarginPercent) / 100));
  const subtotalBeforeGst = baseProductionCost + agencyMarginAmount;
  const gstAmount18 = Math.round(subtotalBeforeGst * 0.18);
  const grandTotalWithGst = subtotalBeforeGst + gstAmount18;
  const costPerFinishedMinute = Math.round(grandTotalWithGst / Math.max(0.5, input.totalFinishedMinutes));
  const costPerViralReel = Math.round(grandTotalWithGst / Math.max(1, input.deliverablesReelsCount));
  const studioUtilizationRate = Math.min(100, Math.round((days / 22) * 100));

  return {
    preProductionCost: preProd,
    shootDaysTotalCost,
    postProductionCost,
    baseProductionCost,
    agencyMarginAmount,
    subtotalBeforeGst,
    gstAmount18,
    grandTotalWithGst,
    costPerFinishedMinute,
    costPerViralReel,
    studioUtilizationRate,
  };
}

/**
 * 4. Client Payment CRM Balance & Status Calculator
 */
export function calculateClientPaymentStatus(totalContractValue: number, paidAmount: number): {
  totalContractValue: number;
  paidAmount: number;
  pendingAmount: number;
  gstAmount: number;
  paymentStatus: 'Paid' | 'Partial' | 'Pending';
} {
  const total = Math.max(0, Math.round(totalContractValue));
  const paid = Math.max(0, Math.min(total, Math.round(paidAmount)));
  const pendingAmount = Math.max(0, total - paid);
  const gstAmount = Math.round(total * 0.18);
  const paymentStatus = pendingAmount === 0 && total > 0 ? 'Paid' : paid > 0 ? 'Partial' : 'Pending';

  return {
    totalContractValue: total,
    paidAmount: paid,
    pendingAmount,
    gstAmount,
    paymentStatus,
  };
}


