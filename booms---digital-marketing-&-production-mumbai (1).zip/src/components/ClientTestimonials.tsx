import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Quote,
  ChevronLeft,
  ChevronRight,
  Pause,
  Play,
  CheckCircle2,
  Star,
  Plus,
  X,
  Sparkles,
  TrendingUp,
  Building2,
  UserCheck,
} from 'lucide-react';
import { ClientTestimonial } from '../types';
import { INITIAL_TESTIMONIALS } from '../utils/portfolioData';
import {
  getProjectIndex,
  validateTestimonialForm,
  calculateAverageRating,
} from '../utils/campaignCalculator';
import { soundFx } from '../utils/soundEffects';

interface ClientTestimonialsProps {
  initialTestimonials?: ClientTestimonial[];
}

const CATEGORIES = [
  'All',
  'Brands & Reels',
  'Commercial Ads',
  'Cinema & Films',
  'Performance Marketing',
];

export const ClientTestimonials: React.FC<ClientTestimonialsProps> = ({
  initialTestimonials = INITIAL_TESTIMONIALS,
}) => {
  const [testimonials, setTestimonials] = useState<ClientTestimonial[]>(initialTestimonials);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeIndex, setActiveIndex] = useState<number>(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState<boolean>(true);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [slideProgress, setSlideProgress] = useState<number>(0);

  // Add Review Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [formName, setFormName] = useState<string>('');
  const [formRole, setFormRole] = useState<string>('');
  const [formCompany, setFormCompany] = useState<string>('');
  const [formCategory, setFormCategory] = useState<string>('Brands & Reels');
  const [formMetric, setFormMetric] = useState<string>('');
  const [formProjectTitle, setFormProjectTitle] = useState<string>('');
  const [formRating, setFormRating] = useState<number>(5);
  const [formQuote, setFormQuote] = useState<string>('');
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submitSuccess, setSubmitSuccess] = useState<string | null>(null);

  const autoSlideDuration = 4500; // 4.5 seconds per slide
  const progressIntervalRef = useRef<number | null>(null);

  const fetchTestimonials = useCallback(async (categoryFilter: string = selectedCategory) => {
    setIsLoading(true);
    try {
      const query =
        categoryFilter && categoryFilter !== 'All'
          ? `?category=${encodeURIComponent(categoryFilter)}`
          : '';
      const response = await fetch(`/api/testimonials${query}`);
      const result = await response.json();
      if (result.success && Array.isArray(result.data)) {
        setTestimonials(result.data);
        setActiveIndex(0);
        setSlideProgress(0);
      }
    } catch {
      // Keep fallback state if offline
    } finally {
      setIsLoading(false);
    }
  }, [selectedCategory]);

  useEffect(() => {
    fetchTestimonials(selectedCategory);
  }, [selectedCategory, fetchTestimonials]);

  const handleNext = useCallback(() => {
    if (testimonials.length <= 1) return;
    setActiveIndex((prev) => getProjectIndex(prev, 1, testimonials.length));
    setSlideProgress(0);
  }, [testimonials.length]);

  const handlePrev = useCallback(() => {
    if (testimonials.length <= 1) return;
    setActiveIndex((prev) => getProjectIndex(prev, -1, testimonials.length));
    setSlideProgress(0);
  }, [testimonials.length]);

  // Horizontal Auto-Sliding Carousel Timer & Smooth Progress Bar
  useEffect(() => {
    if (!isAutoPlaying || isAddModalOpen || testimonials.length <= 1) {
      if (progressIntervalRef.current) {
        window.clearInterval(progressIntervalRef.current);
      }
      return;
    }

    const stepMs = 50;
    const increment = (stepMs / autoSlideDuration) * 100;

    progressIntervalRef.current = window.setInterval(() => {
      setSlideProgress((prev) => {
        if (prev + increment >= 100) {
          setActiveIndex((idx) => getProjectIndex(idx, 1, testimonials.length));
          return 0;
        }
        return prev + increment;
      });
    }, stepMs);

    return () => {
      if (progressIntervalRef.current) {
        window.clearInterval(progressIntervalRef.current);
      }
    };
  }, [isAutoPlaying, isAddModalOpen, testimonials.length]);

  const handleCategorySelect = (category: string) => {
    soundFx.playClick(750);
    setSelectedCategory(category);
  };

  const handleSelectSlide = (idx: number) => {
    soundFx.playClick(820);
    setActiveIndex(idx);
    setSlideProgress(0);
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormErrors({});
    setSubmitSuccess(null);

    const validation = validateTestimonialForm({
      name: formName,
      company: formCompany,
      quote: formQuote,
      rating: formRating,
    });

    if (!validation.isValid) {
      setFormErrors(validation.errors);
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await fetch('/api/testimonials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formName.trim(),
          role: formRole.trim() || 'Founder & Brand Partner',
          company: formCompany.trim(),
          category: formCategory,
          metric: formMetric.trim() || '+125% Campaign Lift',
          projectTitle: formProjectTitle.trim() || 'Booms Studio Production',
          rating: formRating,
          quote: formQuote.trim(),
        }),
      });

      const result = await response.json();
      if (response.ok && result.success) {
        soundFx.playClick(950);
        setSubmitSuccess('Client review published to the live carousel!');
        setFormName('');
        setFormRole('');
        setFormCompany('');
        setFormMetric('');
        setFormProjectTitle('');
        setFormQuote('');
        setFormRating(5);

        // Reset filter to All or matching category so the new review is immediately visible at index 0
        if (selectedCategory !== 'All' && selectedCategory !== formCategory) {
          setSelectedCategory('All');
        } else {
          await fetchTestimonials(selectedCategory);
        }
        setActiveIndex(0);
        setSlideProgress(0);

        setTimeout(() => {
          setIsAddModalOpen(false);
          setSubmitSuccess(null);
        }, 900);
      } else {
        setFormErrors({ submit: result.error || 'Could not publish review.' });
      }
    } catch {
      setFormErrors({ submit: 'Network error while submitting review.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const avgRating = calculateAverageRating(testimonials);

  return (
    <section
      id="testimonials"
      aria-label="Client Testimonials Carousel"
      className="relative py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto z-10 scroll-mt-20 overflow-hidden"
    >
      {/* Ambient Background Glow in #0F172A & Sky */}
      <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-[42rem] h-64 bg-sky-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Section Header */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-12 gap-6 border-b border-slate-800 pb-8">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono uppercase tracking-widest text-sky-400 bg-[#0F172A] border border-slate-700 mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Verified Client Reviews · Live API Feed</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white font-display">
            People Who Transformed Their Brands With Booms.
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-300 leading-relaxed">
            Real feedback from founders, CMOs, and film producers across Mumbai and Pan-India whose campaigns scaled through our studio.
          </p>
        </div>

        {/* Aggregate Trust Badge & Submit Review Action */}
        <div className="flex flex-wrap items-center gap-4 shrink-0">
          <div className="bg-[#0F172A] border border-slate-700 rounded-xl px-4 py-2.5 flex items-center gap-3 shadow-md">
            <div className="flex items-center gap-1 text-sky-400">
              <Star className="w-4 h-4 fill-sky-400 text-sky-400" />
              <span className="font-mono font-bold text-white text-base">{avgRating.toFixed(1)}</span>
            </div>
            <div className="h-4 w-px bg-slate-700" />
            <div className="text-xs font-mono text-slate-300">
              <span data-testid="testimonials-total-count" className="text-sky-400 font-bold">
                {testimonials.length}
              </span>{' '}
              Verified Reviews
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              soundFx.playClick(850);
              setIsAddModalOpen(true);
            }}
            className="inline-flex items-center gap-2 px-4 py-3 text-xs font-semibold text-white bg-[#0F172A] hover:bg-slate-800 border border-sky-500/40 hover:border-sky-400 rounded-xl transition-all shadow-lg cursor-pointer"
          >
            <Plus className="w-4 h-4 text-sky-400" />
            <span>Submit Client Review</span>
          </button>
        </div>
      </div>

      {/* Category Filter Bar & Carousel Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 no-scrollbar">
          {CATEGORIES.map((category) => {
            const active = selectedCategory === category;
            return (
              <button
                key={category}
                type="button"
                onClick={() => handleCategorySelect(category)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-mono transition-all whitespace-nowrap cursor-pointer border ${
                  active
                    ? 'bg-[#0F172A] text-sky-400 border-sky-500/60 shadow-sm font-semibold'
                    : 'bg-[#0b0f19] text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                {category}
              </button>
            );
          })}
        </div>

        {/* Horizontal Carousel Navigation Controls */}
        <div className="flex items-center gap-2 self-end sm:self-auto">
          <button
            type="button"
            onClick={() => {
              soundFx.playClick(720);
              setIsAutoPlaying((prev) => !prev);
            }}
            aria-label={isAutoPlaying ? 'Pause auto-sliding carousel' : 'Resume auto-sliding carousel'}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-mono bg-[#0F172A] hover:bg-slate-800 text-slate-300 border border-slate-700 transition-colors cursor-pointer"
          >
            {isAutoPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5 text-sky-400" />
                <span>Auto-Slide On</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 text-slate-400" />
                <span>Paused</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => {
              soundFx.playClick(760);
              handlePrev();
            }}
            aria-label="Previous client testimonial"
            className="p-2 rounded-lg bg-[#0F172A] hover:bg-slate-800 text-white border border-slate-700 hover:border-sky-500/50 transition-all cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4 text-sky-400" />
          </button>

          <button
            type="button"
            onClick={() => {
              soundFx.playClick(820);
              handleNext();
            }}
            aria-label="Next client testimonial"
            className="p-2 rounded-lg bg-[#0F172A] hover:bg-slate-800 text-white border border-slate-700 hover:border-sky-500/50 transition-all cursor-pointer"
          >
            <ChevronRight className="w-4 h-4 text-sky-400" />
          </button>
        </div>
      </div>

      {/* Main Horizontal Auto-Sliding Carousel Viewport */}
      {isLoading && testimonials.length === 0 ? (
        <div className="bg-[#0F172A]/60 border border-slate-800 rounded-2xl p-12 text-center text-slate-400 font-mono text-sm">
          Loading verified client reviews from studio API...
        </div>
      ) : testimonials.length === 0 ? (
        <div className="bg-[#0F172A]/60 border border-slate-800 rounded-2xl p-12 text-center">
          <p className="text-slate-300 text-base">No reviews found for this category.</p>
          <button
            type="button"
            onClick={() => setSelectedCategory('All')}
            className="mt-4 px-4 py-2 text-xs font-mono text-sky-400 bg-[#0F172A] border border-slate-700 rounded-lg"
          >
            Reset Filter
          </button>
        </div>
      ) : (
        <div
          className="relative overflow-hidden rounded-2xl bg-[#0a0f1c] border border-slate-800/90 shadow-2xl"
          onMouseEnter={() => setIsAutoPlaying(false)}
          onMouseLeave={() => setIsAutoPlaying(true)}
        >
          {/* Top Auto-Slide Progress Bar */}
          <div className="w-full h-1 bg-slate-900 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#0F172A] via-sky-500 to-sky-400 transition-all duration-75"
              style={{ width: `${isAutoPlaying ? slideProgress : 100}%` }}
            />
          </div>

          {/* Horizontal Sliding Track (CSS Transform TranslateX) */}
          <div
            data-testid="testimonials-carousel-track"
            className="flex transition-transform duration-700 ease-out will-change-transform"
            style={{ transform: `translateX(-${activeIndex * 100}%)` }}
          >
            {testimonials.map((item, idx) => (
              <div
                key={item.id}
                aria-hidden={idx !== activeIndex}
                className="w-full shrink-0 p-6 sm:p-10 lg:p-12"
              >
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                  {/* Left Column: Client Profile & Verified Impact Card */}
                  <div className="lg:col-span-4 bg-[#0F172A] border border-slate-700/80 rounded-2xl p-6 flex flex-col justify-between h-full shadow-lg">
                    <div>
                      <div className="flex items-center gap-4 mb-5">
                        <img
                          src={item.avatar}
                          alt={item.name}
                          referrerPolicy="no-referrer"
                          className="w-16 h-16 rounded-2xl object-cover border-2 border-sky-500/40 shadow-md"
                        />
                        <div>
                          <div className="inline-flex items-center gap-1 text-[11px] font-mono text-emerald-400 bg-slate-900/90 px-2 py-0.5 rounded-md border border-slate-700 mb-1">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Verified Partner</span>
                          </div>
                          <h3 className="text-lg font-bold text-white font-display leading-snug">
                            {item.name}
                          </h3>
                          <p className="text-xs text-slate-300">{item.role}</p>
                        </div>
                      </div>

                      <div className="space-y-2.5 pt-4 border-t border-slate-800 text-xs">
                        <div className="flex items-center justify-between text-slate-300">
                          <span className="text-slate-400 flex items-center gap-1.5">
                            <Building2 className="w-3.5 h-3.5 text-sky-400" />
                            Brand:
                          </span>
                          <span className="font-semibold text-white text-right">{item.company}</span>
                        </div>

                        {item.projectTitle && (
                          <div className="flex items-center justify-between text-slate-300">
                            <span className="text-slate-400">Campaign:</span>
                            <span className="font-mono text-sky-400 text-right">{item.projectTitle}</span>
                          </div>
                        )}

                        <div className="flex items-center justify-between text-slate-300">
                          <span className="text-slate-400">Category:</span>
                          <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 font-mono text-[11px] text-slate-200">
                            {item.category}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Measurable Impact Pill */}
                    <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between bg-slate-900/70 rounded-xl px-4 py-3 border border-slate-800">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-sky-400 shrink-0" />
                        <span className="text-xs text-slate-400">Measured Outcome</span>
                      </div>
                      <span className="text-xs sm:text-sm font-mono font-bold text-sky-400">
                        {item.metric}
                      </span>
                    </div>
                  </div>

                  {/* Right Column: Large Spotlight Quote & Rating */}
                  <div className="lg:col-span-8 flex flex-col justify-between h-full lg:pl-4">
                    <div>
                      <div className="flex items-center justify-between mb-6">
                        {/* 5-Star Rating in Sky-400 (No Yellow/Amber) */}
                        <div className="flex items-center gap-1.5" aria-label={`Rated ${item.rating} out of 5 stars`}>
                          {Array.from({ length: 5 }).map((_, starIdx) => (
                            <Star
                              key={starIdx}
                              className={`w-4 h-4 ${
                                starIdx < item.rating
                                  ? 'fill-sky-400 text-sky-400'
                                  : 'text-slate-700'
                              }`}
                            />
                          ))}
                          <span className="ml-2 text-xs font-mono text-slate-400">
                            {item.rating}.0 / 5.0 Studio Rating
                          </span>
                        </div>

                        <Quote className="w-10 h-10 text-slate-800 hidden sm:block" />
                      </div>

                      <blockquote className="text-lg sm:text-2xl lg:text-3xl font-medium text-slate-100 leading-relaxed font-display">
                        "{item.quote}"
                      </blockquote>
                    </div>

                    <div className="mt-8 pt-6 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-4">
                      <div className="text-xs font-mono text-slate-400">
                        Slide <span className="text-white font-bold">{idx + 1}</span> of{' '}
                        <span className="text-white font-bold">{testimonials.length}</span> · Produced at Booms Mumbai Studio
                      </div>

                      {/* Slide Pagination Dots */}
                      <div className="flex items-center gap-2">
                        {testimonials.map((dotItem, dotIdx) => (
                          <button
                            key={dotItem.id}
                            type="button"
                            onClick={() => handleSelectSlide(dotIdx)}
                            aria-label={`Go to testimonial ${dotIdx + 1} by ${dotItem.name}`}
                            className={`h-2 rounded-full transition-all cursor-pointer ${
                              dotIdx === activeIndex
                                ? 'w-8 bg-sky-400'
                                : 'w-2 bg-slate-700 hover:bg-slate-500'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Horizontal Auto-Sliding Overview Strip (Quick-Select Cards) */}
      {testimonials.length > 1 && (
        <div className="mt-8">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
              All Client Reviews · Click Any Card to Spotlight
            </span>
            <span className="text-xs font-mono text-sky-400">
              Active: {testimonials[activeIndex]?.name}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {testimonials.map((item, idx) => {
              const isCurrent = idx === activeIndex;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleSelectSlide(idx)}
                  className={`text-left p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                    isCurrent
                      ? 'bg-[#0F172A] border-sky-500/70 shadow-lg ring-1 ring-sky-500/30'
                      : 'bg-[#0b101b]/80 border-slate-800/90 hover:border-slate-700 opacity-80 hover:opacity-100'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <img
                          src={item.avatar}
                          alt={item.name}
                          referrerPolicy="no-referrer"
                          className="w-9 h-9 rounded-full object-cover border border-slate-700 shrink-0"
                        />
                        <div className="truncate">
                          <div className="text-xs font-bold text-white truncate">{item.name}</div>
                          <div className="text-[11px] text-slate-400 truncate">{item.company}</div>
                        </div>
                      </div>
                      <span className="text-[10px] font-mono text-sky-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800 shrink-0">
                        {item.metric}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 line-clamp-2 italic">"{item.quote}"</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Submit Client Review Modal */}
      {isAddModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="submit-review-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
        >
          <div className="bg-[#0F172A] border border-slate-700 rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-center text-sky-400">
                  <UserCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 id="submit-review-modal-title" className="text-lg font-bold text-white font-display">
                    Submit Client Review
                  </h3>
                  <p className="text-xs text-slate-400">
                    Publishes directly to the live horizontal testimonial carousel
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                aria-label="Close review modal"
                className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitReview} className="space-y-4" noValidate>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="review-client-name" className="block text-xs font-mono text-slate-300 mb-1">
                    Client Full Name *
                  </label>
                  <input
                    id="review-client-name"
                    type="text"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="e.g. Siddharth Malhotra"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-sky-400"
                  />
                  {formErrors.name && (
                    <p className="text-xs text-rose-400 mt-1">{formErrors.name}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="review-client-role" className="block text-xs font-mono text-slate-300 mb-1">
                    Role / Designation
                  </label>
                  <input
                    id="review-client-role"
                    type="text"
                    value={formRole}
                    onChange={(e) => setFormRole(e.target.value)}
                    placeholder="e.g. CMO & Co-Founder"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-sky-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="review-company" className="block text-xs font-mono text-slate-300 mb-1">
                    Company / Brand Name *
                  </label>
                  <input
                    id="review-company"
                    type="text"
                    value={formCompany}
                    onChange={(e) => setFormCompany(e.target.value)}
                    placeholder="e.g. Elevate Lifestyle"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-sky-400"
                  />
                  {formErrors.company && (
                    <p className="text-xs text-rose-400 mt-1">{formErrors.company}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="review-category" className="block text-xs font-mono text-slate-300 mb-1">
                    Campaign Category
                  </label>
                  <select
                    id="review-category"
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-sky-400"
                  >
                    {CATEGORIES.filter((c) => c !== 'All').map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="review-metric" className="block text-xs font-mono text-slate-300 mb-1">
                    Key Result / Metric
                  </label>
                  <input
                    id="review-metric"
                    type="text"
                    value={formMetric}
                    onChange={(e) => setFormMetric(e.target.value)}
                    placeholder="e.g. +180% ROAS Lift"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-sky-400"
                  />
                </div>

                <div>
                  <label htmlFor="review-rating" className="block text-xs font-mono text-slate-300 mb-1">
                    Rating (1 - 5 Stars)
                  </label>
                  <select
                    id="review-rating"
                    value={formRating}
                    onChange={(e) => setFormRating(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-sky-400"
                  >
                    <option value={5}>5 Stars (Exceptional)</option>
                    <option value={4}>4 Stars (Great)</option>
                    <option value={3}>3 Stars (Good)</option>
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="review-quote" className="block text-xs font-mono text-slate-300 mb-1">
                  Client Review / Testimonial Quote *
                </label>
                <textarea
                  id="review-quote"
                  rows={3}
                  value={formQuote}
                  onChange={(e) => setFormQuote(e.target.value)}
                  placeholder="Share how Booms transformed your brand production or digital growth..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-sky-400"
                />
                {formErrors.quote && (
                  <p className="text-xs text-rose-400 mt-1">{formErrors.quote}</p>
                )}
              </div>

              {formErrors.submit && (
                <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-700 text-xs text-rose-300">
                  {formErrors.submit}
                </div>
              )}

              {submitSuccess && (
                <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-700 text-xs text-emerald-300">
                  {submitSuccess}
                </div>
              )}

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-mono text-slate-300 hover:text-white bg-slate-900 border border-slate-700 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 transition-colors shadow-lg cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? 'Publishing...' : 'Publish Review'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
