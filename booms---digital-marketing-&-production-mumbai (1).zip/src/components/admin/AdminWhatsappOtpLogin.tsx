import React, { useState } from 'react';
import {
  ShieldCheck,
  Smartphone,
  MessageSquare,
  Lock,
  ArrowRight,
  CheckCircle2,
  ExternalLink,
  AlertCircle,
  KeyRound,
  RefreshCw,
} from 'lucide-react';
import { soundFx } from '../../utils/soundEffects';

export interface AdminSession {
  phone: string;
  role: string;
  verifiedVia: string;
  verifiedAt: string;
}

interface AdminWhatsappOtpLoginProps {
  onVerified: (session: AdminSession) => void;
  onCancel: () => void;
}

export const AdminWhatsappOtpLogin: React.FC<AdminWhatsappOtpLoginProps> = ({
  onVerified,
  onCancel,
}) => {
  const [phone, setPhone] = useState('+91 8006603090');
  const [otpSent, setOtpSent] = useState(false);
  const [otpInput, setOtpInput] = useState('');
  const [dispatchedOtp, setDispatchedOtp] = useState<string | null>(null);
  const [whatsappLink, setWhatsappLink] = useState<string | null>(null);
  const [formattedPhone, setFormattedPhone] = useState<string>('+91 8006603090');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await fetch('/api/admin/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone }),
      });
      const data = await res.json();

      if (res.ok && data.success) {
        soundFx.playClick(880);
        setOtpSent(true);
        setDispatchedOtp(data.otpCode);
        setWhatsappLink(data.whatsappLink);
        setFormattedPhone(data.formattedPhone || phone);
      } else {
        setError(data.error || 'Could not dispatch WhatsApp OTP.');
      }
    } catch {
      setError('Network error while connecting to Admin OTP gateway.');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (codeToVerify?: string) => {
    const finalOtp = (codeToVerify ?? otpInput).trim();
    if (!finalOtp || finalOtp.length < 6) {
      setError('Please enter the 6-digit WhatsApp OTP.');
      return;
    }

    setError(null);
    setLoading(true);

    try {
      const res = await fetch('/api/admin/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, otp: finalOtp }),
      });
      const data = await res.json();

      if (res.ok && data.success) {
        soundFx.playBoom();
        onVerified(data.adminSession);
      } else {
        setError(data.error || 'Invalid OTP code.');
      }
    } catch {
      setError('Network error verifying OTP.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 sm:p-10 flex flex-col items-center justify-center min-h-[480px] bg-[#090d16]">
      <div className="w-full max-w-md bg-[#0F172A] border border-slate-700/90 rounded-2xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-slate-900 border border-sky-500/40 flex items-center justify-center text-sky-400 shrink-0 shadow-md">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-mono uppercase tracking-widest text-emerald-400 block">
              WhatsApp 2FA Security Gate
            </span>
            <h4 className="text-xl font-bold text-white font-display">
              Booms Admin Panel Login
            </h4>
          </div>
        </div>

        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
          The Studio Dashboard, Client Management &amp; Payment CRM, and Formula Suite are protected inside the Admin Panel. Authenticate with your registered mobile number via WhatsApp OTP.
        </p>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-950/80 border border-rose-800 text-xs text-rose-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {!otpSent ? (
          <form onSubmit={handleSendOtp} className="space-y-4">
            <div>
              <label
                htmlFor="admin-whatsapp-mobile"
                className="block text-xs font-mono uppercase tracking-wider text-slate-300 mb-1.5"
              >
                Admin Mobile Number (WhatsApp) *
              </label>
              <div className="relative">
                <Smartphone className="w-4 h-4 text-sky-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  id="admin-whatsapp-mobile"
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 8006603090"
                  required
                  className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-sm font-mono text-white focus:outline-none focus:border-sky-400"
                />
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">
                Official Admin Number: +91 8006603090
              </span>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl text-xs sm:text-sm font-bold text-white bg-emerald-700 hover:bg-emerald-600 border border-emerald-500/50 transition-all shadow-lg cursor-pointer disabled:opacity-50"
            >
              {loading ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <MessageSquare className="w-4 h-4" />
              )}
              <span>Send OTP on WhatsApp</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        ) : (
          <div className="space-y-5">
            {/* Simulated Live WhatsApp Message Notification Banner */}
            {dispatchedOtp && (
              <div
                data-testid="whatsapp-otp-banner"
                className="p-4 rounded-xl bg-emerald-950/70 border border-emerald-700/80 space-y-2.5 shadow-inner"
              >
                <div className="flex items-center justify-between">
                  <span className="inline-flex items-center gap-1.5 text-[11px] font-mono font-bold text-emerald-300 uppercase">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    WhatsApp Message Dispatched
                  </span>
                  <span className="text-[11px] font-mono text-slate-300">{formattedPhone}</span>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-900/90 border border-slate-800 text-xs text-slate-200 font-mono flex items-center justify-between">
                  <span>
                    WhatsApp OTP: <strong className="text-sky-400 text-sm">{dispatchedOtp}</strong>
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setOtpInput(dispatchedOtp);
                      handleVerifyOtp(dispatchedOtp);
                    }}
                    className="px-2.5 py-1 rounded bg-[#0F172A] hover:bg-slate-800 text-sky-400 border border-sky-500/40 text-[11px] font-semibold cursor-pointer"
                  >
                    Auto-Fill &amp; Verify
                  </button>
                </div>

                {whatsappLink && (
                  <div className="flex items-center justify-between pt-1">
                    <a
                      href={whatsappLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[11px] font-mono text-emerald-300 hover:text-white underline"
                    >
                      <span>Open Message in WhatsApp App</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                    <button
                      type="button"
                      onClick={() => {
                        setOtpSent(false);
                        setOtpInput('');
                      }}
                      className="text-[11px] font-mono text-slate-400 hover:text-white cursor-pointer"
                    >
                      Change Number
                    </button>
                  </div>
                )}
              </div>
            )}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleVerifyOtp();
              }}
              className="space-y-4"
            >
              <div>
                <label
                  htmlFor="admin-otp-code-input"
                  className="block text-xs font-mono uppercase tracking-wider text-slate-300 mb-1.5"
                >
                  Enter 6-Digit WhatsApp OTP *
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-sky-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    id="admin-otp-code-input"
                    type="text"
                    maxLength={6}
                    value={otpInput}
                    onChange={(e) => setOtpInput(e.target.value.replace(/[^\d]/g, ''))}
                    placeholder="Enter 6-digit OTP"
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-base font-mono tracking-widest text-white focus:outline-none focus:border-sky-400"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl text-xs sm:text-sm font-bold text-white bg-sky-600 hover:bg-sky-500 transition-all shadow-lg cursor-pointer disabled:opacity-50"
              >
                <Lock className="w-4 h-4" />
                <span>{loading ? 'Verifying OTP...' : 'Verify OTP & Unlock Admin CRM'}</span>
              </button>
            </form>
          </div>
        )}

        <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>Protected Admin Mode · Booms.in</span>
          <button
            type="button"
            onClick={onCancel}
            className="text-slate-400 hover:text-white font-mono cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
