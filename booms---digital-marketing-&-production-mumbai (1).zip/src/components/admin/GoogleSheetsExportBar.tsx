import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  Download,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  LogOut,
} from 'lucide-react';
import { User } from 'firebase/auth';
import {
  initAuth,
  googleSignIn,
  logoutGoogle,
  exportReportToGoogleSheets,
  downloadReportCsv,
  ReportExportPayload,
} from '../../utils/googleSheetsService';
import { soundFx } from '../../utils/soundEffects';

interface GoogleSheetsExportBarProps {
  payload: ReportExportPayload;
}

export const GoogleSheetsExportBar: React.FC<GoogleSheetsExportBarProps> = ({ payload }) => {
  const [needsAuth, setNeedsAuth] = useState(true);
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [createdSheet, setCreatedSheet] = useState<{
    spreadsheetId: string;
    spreadsheetUrl: string;
    title: string;
  } | null>(null);
  const [exportError, setExportError] = useState<string | null>(null);
  const [csvDownloaded, setCsvDownloaded] = useState(false);

  useEffect(() => {
    const unsub = initAuth(
      (u, t) => {
        setUser(u);
        setToken(t);
        setNeedsAuth(false);
      },
      () => {
        setUser(null);
        setToken(null);
        setNeedsAuth(true);
      }
    );
    return () => unsub();
  }, []);

  const handleGoogleLogin = async () => {
    setIsLoggingIn(true);
    setExportError(null);
    try {
      const result = await googleSignIn();
      if (result) {
        soundFx.playClick(900);
        setUser(result.user);
        setToken(result.accessToken);
        setNeedsAuth(false);
      }
    } catch (err: any) {
      setExportError(err?.message || 'Google sign-in was cancelled or blocked by popup settings.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleConfirmExportToGoogleSheets = async () => {
    if (!token) {
      setNeedsAuth(true);
      setShowConfirmModal(false);
      return;
    }

    setIsExporting(true);
    setExportError(null);
    try {
      const sheet = await exportReportToGoogleSheets(token, payload);
      soundFx.playBoom();
      setCreatedSheet(sheet);
      setShowConfirmModal(false);
    } catch (err: any) {
      setExportError(err?.message || 'Could not export to Google Sheets.');
      setShowConfirmModal(false);
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownloadCsv = () => {
    soundFx.playClick(860);
    downloadReportCsv(payload);
    setCsvDownloaded(true);
    setTimeout(() => setCsvDownloaded(false), 3500);
  };

  return (
    <div className="bg-[#090d16] border-b border-slate-800 px-6 py-3">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-950/80 border border-emerald-700/70 flex items-center justify-center text-emerald-400 shrink-0">
            <FileSpreadsheet className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-bold text-white flex items-center gap-2">
              <span>Google Sheets Report Exporter</span>
              <span className="text-[10px] font-mono text-sky-400 bg-[#0F172A] px-2 py-0.5 rounded border border-slate-700">
                {payload.clients.length} Clients · {payload.formulaMetrics.length} Formulas · {payload.leads.length} Leads
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Export Clients CRM, Payment Ledgers &amp; Marketing/Production Formulas directly to Google Sheets
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Instant CSV Download for Google Sheets */}
          <button
            type="button"
            onClick={handleDownloadCsv}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold text-emerald-300 bg-emerald-950/70 hover:bg-emerald-900/80 border border-emerald-700/70 transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>
              {csvDownloaded ? 'Report Downloaded (.csv)!' : 'Download Google Sheet (.csv)'}
            </span>
          </button>

          {/* Official Google Sign-In or Live Google Sheets API Export Button */}
          {needsAuth || !token ? (
            <button
              type="button"
              onClick={handleGoogleLogin}
              disabled={isLoggingIn}
              className="gsi-material-button inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-white hover:bg-slate-100 text-slate-900 text-xs font-semibold shadow transition-all cursor-pointer disabled:opacity-50"
            >
              <div className="gsi-material-button-state" />
              <div className="gsi-material-button-content-wrapper flex items-center gap-2">
                <div className="gsi-material-button-icon w-4 h-4 shrink-0">
                  <svg
                    version="1.1"
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 48 48"
                    style={{ display: 'block' }}
                  >
                    <path
                      fill="#EA4335"
                      d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                    />
                    <path
                      fill="#4285F4"
                      d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                    />
                    <path
                      fill="#34A853"
                      d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                    />
                    <path fill="none" d="M0 0h48v48H0z" />
                  </svg>
                </div>
                <span className="gsi-material-button-contents">
                  {isLoggingIn ? 'Connecting Google...' : 'Sign in with Google for Live Sheet'}
                </span>
              </div>
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={isExporting}
                onClick={() => setShowConfirmModal(true)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-bold text-white bg-sky-600 hover:bg-sky-500 transition-all shadow cursor-pointer"
              >
                {isExporting ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                )}
                <span>Export Live to Google Sheets</span>
              </button>

              <button
                type="button"
                onClick={() => logoutGoogle()}
                title={`Signed in as ${user?.email || 'Google User'}`}
                className="p-2 rounded-lg bg-[#0F172A] border border-slate-700 text-slate-400 hover:text-white cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Created Google Sheet Success Link */}
      {createdSheet && (
        <div className="mt-2.5 p-2.5 rounded-lg bg-emerald-950/80 border border-emerald-700 text-xs text-emerald-200 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              Created Google Sheet: <strong>{createdSheet.title}</strong>
            </span>
          </div>
          <a
            href={createdSheet.spreadsheetUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-700 hover:bg-emerald-600 text-white font-semibold"
          >
            <span>Open in Google Sheets</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      )}

      {exportError && (
        <div className="mt-2.5 p-2.5 rounded-lg bg-rose-950/80 border border-rose-800 text-xs text-rose-300 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{exportError}</span>
          </div>
          <button
            type="button"
            onClick={() => setExportError(null)}
            className="text-[11px] font-mono underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Mandatory User Confirmation Dialog before Writing to Google Sheets */}
      {showConfirmModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
        >
          <div className="bg-[#0F172A] border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <h4 className="text-base font-bold text-white font-display flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
              <span>Confirm Google Sheets Export</span>
            </h4>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              This will create and populate a new 3-tab Google Spreadsheet in your Google Workspace account (<strong>{user?.email}</strong>) containing:
            </p>
            <ul className="text-xs text-slate-300 font-mono space-y-1 bg-slate-900 p-3 rounded-xl border border-slate-800">
              <li>• {payload.clients.length} Client Accounts &amp; Payment Ledgers</li>
              <li>• {payload.formulaMetrics.length} Digital Marketing, Social &amp; Production Formulas</li>
              <li>• {payload.leads.length} Website Inquiries &amp; Leads</li>
            </ul>
            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 rounded-lg text-xs font-mono text-slate-300 bg-slate-900 border border-slate-700 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isExporting}
                onClick={handleConfirmExportToGoogleSheets}
                className="px-4 py-2 rounded-lg text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 cursor-pointer"
              >
                {isExporting ? 'Creating Google Sheet...' : 'Confirm & Create Sheet'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
