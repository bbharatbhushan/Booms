import React, { useState } from 'react';
import {
  Briefcase,
  IndianRupee,
  Plus,
  CheckCircle2,
  AlertCircle,
  MessageSquare,
  CreditCard,
  Trash2,
  Calculator,
  Calendar,
  Building2,
  Phone,
  Mail,
  RefreshCw,
} from 'lucide-react';
import { CrmClient } from '../../types';
import { formatINR } from '../../utils/campaignCalculator';
import { soundFx } from '../../utils/soundEffects';

interface ClientsPaymentCrmTabProps {
  clients: CrmClient[];
  onRefreshClients: () => void;
}

export const ClientsPaymentCrmTab: React.FC<ClientsPaymentCrmTabProps> = ({
  clients,
  onRefreshClients,
}) => {
  // Add New Client Form State
  const [showAddForm, setShowAddForm] = useState(false);
  const [clientName, setClientName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [phone, setPhone] = useState('+91 ');
  const [email, setEmail] = useState('');
  const [gstNumber, setGstNumber] = useState('');
  const [servicePackage, setServicePackage] = useState<CrmClient['servicePackage']>(
    '360° Full Studio Retainer'
  );
  const [totalContractValue, setTotalContractValue] = useState('500000');
  const [paidAmount, setPaidAmount] = useState('250000');
  const [dueDate, setDueDate] = useState('2026-12-01');
  const [deliverablesSummary, setDeliverablesSummary] = useState('');
  const [isSubmittingClient, setIsSubmittingClient] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  // Record Payment State
  const [activePaymentClientId, setActivePaymentClientId] = useState<string | null>(null);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'NEFT/RTGS' | 'Razorpay' | 'Cheque'>('UPI');
  const [paymentRef, setPaymentRef] = useState('');
  const [paymentNote, setPaymentNote] = useState('');
  const [isRecordingPayment, setIsRecordingPayment] = useState(false);

  // Filter state
  const [paymentFilter, setPaymentFilter] = useState<'All' | 'Paid' | 'Partial' | 'Pending'>('All');

  const totalContractSum = clients.reduce((sum, c) => sum + Number(c.totalContractValue || 0), 0);
  const totalPaidSum = clients.reduce((sum, c) => sum + Number(c.paidAmount || 0), 0);
  const totalPendingSum = clients.reduce((sum, c) => sum + Number(c.pendingAmount || 0), 0);
  const totalGstSum = clients.reduce((sum, c) => sum + Number(c.gstAmount || 0), 0);

  const filteredClients =
    paymentFilter === 'All'
      ? clients
      : clients.filter((c) => c.paymentStatus === paymentFilter);

  const handleCreateClient = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    if (!clientName.trim() || !companyName.trim() || !Number(totalContractValue)) {
      setStatusMessage({
        type: 'error',
        text: 'Please provide Client Name, Company Name, and a valid Contract Value.',
      });
      return;
    }

    setIsSubmittingClient(true);
    try {
      const res = await fetch('/api/crm/clients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientName: clientName.trim(),
          companyName: companyName.trim(),
          phone: phone.trim(),
          email: email.trim(),
          gstNumber: gstNumber.trim(),
          servicePackage,
          totalContractValue: Number(totalContractValue),
          paidAmount: Number(paidAmount) || 0,
          dueDate,
          deliverablesSummary:
            deliverablesSummary.trim() ||
            'Cinema Commercial Shoot, Vertical Reels Pipeline & Performance Ad Scaling',
        }),
      });
      const data = await res.json();

      if (res.ok && data.success) {
        soundFx.playClick(920);
        setStatusMessage({
          type: 'success',
          text: `Added ${companyName} to Client & Payment CRM!`,
        });
        setClientName('');
        setCompanyName('');
        setPhone('+91 ');
        setEmail('');
        setGstNumber('');
        setDeliverablesSummary('');
        setShowAddForm(false);
        onRefreshClients();
      } else {
        setStatusMessage({
          type: 'error',
          text: data.error || 'Could not add client.',
        });
      }
    } catch {
      setStatusMessage({
        type: 'error',
        text: 'Network error while saving client.',
      });
    } finally {
      setIsSubmittingClient(false);
    }
  };

  const handleRecordPayment = async (clientId: string) => {
    const val = Number(paymentAmount);
    if (!val || val <= 0) {
      setStatusMessage({ type: 'error', text: 'Enter a valid payment installment amount.' });
      return;
    }

    setIsRecordingPayment(true);
    try {
      const res = await fetch(`/api/crm/clients/${clientId}/payments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: val,
          method: paymentMethod,
          referenceNo: paymentRef.trim() || `UTR-${Math.floor(100000 + Math.random() * 900000)}`,
          note: paymentNote.trim() || 'Installment Received',
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        soundFx.playClick(950);
        setStatusMessage({
          type: 'success',
          text: `Payment of ${formatINR(val)} recorded! Client ledger updated.`,
        });
        setActivePaymentClientId(null);
        setPaymentAmount('');
        setPaymentRef('');
        setPaymentNote('');
        onRefreshClients();
      } else {
        setStatusMessage({ type: 'error', text: data.error || 'Failed to record payment.' });
      }
    } catch {
      setStatusMessage({ type: 'error', text: 'Network error recording payment.' });
    } finally {
      setIsRecordingPayment(false);
    }
  };

  const handleUpdateProjectStatus = async (clientId: string, projectStatus: string) => {
    try {
      const res = await fetch(`/api/crm/clients/${clientId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectStatus }),
      });
      if (res.ok) {
        onRefreshClients();
      }
    } catch {
      // Handled gracefully
    }
  };

  const handleDeleteClient = async (clientId: string) => {
    try {
      const res = await fetch(`/api/crm/clients/${clientId}`, { method: 'DELETE' });
      if (res.ok) {
        onRefreshClients();
      }
    } catch {
      // Handled gracefully
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Financial Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-[#0F172A] border border-slate-700/80 rounded-xl p-4 shadow-md">
          <div className="text-[11px] font-mono uppercase text-slate-400">
            Total Contract Ledger
          </div>
          <div
            data-testid="crm-total-contract"
            className="text-xl sm:text-2xl font-bold font-mono text-white mt-1"
          >
            {formatINR(totalContractSum)}
          </div>
          <div className="text-[11px] text-sky-400 mt-1 font-mono">
            {clients.length} Active Brand Accounts
          </div>
        </div>

        <div className="bg-[#0F172A] border border-emerald-800/60 rounded-xl p-4 shadow-md">
          <div className="text-[11px] font-mono uppercase text-slate-400">
            Total Collected (Paid)
          </div>
          <div
            data-testid="crm-total-paid"
            className="text-xl sm:text-2xl font-bold font-mono text-emerald-400 mt-1"
          >
            {formatINR(totalPaidSum)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">
            {clients.filter((c) => c.paymentStatus === 'Paid').length} Fully Settled
          </div>
        </div>

        <div className="bg-[#0F172A] border border-rose-800/60 rounded-xl p-4 shadow-md">
          <div className="text-[11px] font-mono uppercase text-slate-400">
            Pending Receivables
          </div>
          <div
            data-testid="crm-total-pending"
            className="text-xl sm:text-2xl font-bold font-mono text-rose-400 mt-1"
          >
            {formatINR(totalPendingSum)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">
            {clients.filter((c) => c.pendingAmount > 0).length} Accounts with Balance
          </div>
        </div>

        <div className="bg-[#0F172A] border border-slate-700/80 rounded-xl p-4 shadow-md">
          <div className="text-[11px] font-mono uppercase text-slate-400">
            18% GST Tax Ledger
          </div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-sky-400 mt-1">
            {formatINR(totalGstSum)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">
            Auto-Calculated @ 18% GST
          </div>
        </div>
      </div>

      {/* Action Bar & Status Filters */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#0e1320] border border-slate-800 p-4 rounded-xl">
        <div className="flex items-center gap-2 overflow-x-auto">
          {(['All', 'Paid', 'Partial', 'Pending'] as const).map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setPaymentFilter(st)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all cursor-pointer border ${
                paymentFilter === st
                  ? 'bg-[#0F172A] text-sky-400 border-sky-500/60 font-bold'
                  : 'bg-[#090d16] text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              {st === 'All' ? `All Clients (${clients.length})` : st}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              soundFx.playClick(820);
              setShowAddForm((prev) => !prev);
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold text-white bg-sky-600 hover:bg-sky-500 transition-colors cursor-pointer shadow"
          >
            <Plus className="w-4 h-4" />
            <span>{showAddForm ? 'Close Form' : 'Add New Client & Contract'}</span>
          </button>

          <button
            type="button"
            onClick={onRefreshClients}
            aria-label="Refresh CRM Clients"
            className="p-2 rounded-lg bg-[#0F172A] border border-slate-700 text-sky-400 hover:bg-slate-800 cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {statusMessage && (
        <div
          className={`p-3 rounded-xl text-xs font-medium flex items-center justify-between gap-2 ${
            statusMessage.type === 'success'
              ? 'bg-emerald-950/80 border border-emerald-700 text-emerald-300'
              : 'bg-rose-950/80 border border-rose-700 text-rose-300'
          }`}
        >
          <div className="flex items-center gap-2">
            {statusMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span>{statusMessage.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setStatusMessage(null)}
            className="text-[11px] font-mono underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Add New Client Account Form */}
      {showAddForm && (
        <form
          onSubmit={handleCreateClient}
          className="bg-[#0F172A] border border-sky-500/40 rounded-xl p-5 space-y-4 shadow-xl"
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h4 className="text-sm font-bold text-white font-display flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-sky-400" />
              <span>Onboard New Client &amp; Payment Retainer</span>
            </h4>
            <span className="text-[11px] font-mono text-slate-400">
              Auto-calculates Pending Balance &amp; 18% GST
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label htmlFor="crm-client-name" className="block text-[11px] font-mono text-slate-300 uppercase mb-1">
                Client Contact Name *
              </label>
              <input
                id="crm-client-name"
                type="text"
                required
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                placeholder="e.g. Kabir Malhotra"
                className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label htmlFor="crm-company-name" className="block text-[11px] font-mono text-slate-300 uppercase mb-1">
                Company / Brand Name *
              </label>
              <input
                id="crm-company-name"
                type="text"
                required
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="e.g. Zenith Luxury Watches"
                className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label htmlFor="crm-client-phone" className="block text-[11px] font-mono text-slate-300 uppercase mb-1">
                WhatsApp Mobile Number *
              </label>
              <input
                id="crm-client-phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+91 9820012345"
                className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label htmlFor="crm-service-pkg" className="block text-[11px] font-mono text-slate-300 uppercase mb-1">
                Service Package
              </label>
              <select
                id="crm-service-pkg"
                value={servicePackage}
                onChange={(e) => setServicePackage(e.target.value as CrmClient['servicePackage'])}
                className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              >
                <option value="360° Full Studio Retainer">360° Full Studio Retainer</option>
                <option value="Commercial Video Production">Commercial Video Production</option>
                <option value="Social Media Management & Reels">Social Media Management &amp; Reels</option>
                <option value="Digital Marketing & Performance Ads">Digital Marketing &amp; Performance Ads</option>
              </select>
            </div>

            <div>
              <label htmlFor="crm-contract-val" className="block text-[11px] font-mono text-slate-300 uppercase mb-1">
                Total Contract Value (INR) *
              </label>
              <input
                id="crm-contract-val"
                type="number"
                required
                value={totalContractValue}
                onChange={(e) => setTotalContractValue(e.target.value)}
                className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
              />
            </div>

            <div>
              <label htmlFor="crm-paid-val" className="block text-[11px] font-mono text-slate-300 uppercase mb-1">
                Initial Advance Paid (INR)
              </label>
              <input
                id="crm-paid-val"
                type="number"
                value={paidAmount}
                onChange={(e) => setPaidAmount(e.target.value)}
                className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label htmlFor="crm-client-email" className="block text-[11px] font-mono text-slate-300 uppercase mb-1">
                Billing Email
              </label>
              <input
                id="crm-client-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="billing@brand.in"
                className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label htmlFor="crm-gstin" className="block text-[11px] font-mono text-slate-300 uppercase mb-1">
                Client GSTIN
              </label>
              <input
                id="crm-gstin"
                type="text"
                value={gstNumber}
                onChange={(e) => setGstNumber(e.target.value)}
                placeholder="27AAAAA0000A1Z5"
                className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
              />
            </div>

            <div>
              <label htmlFor="crm-due-date" className="block text-[11px] font-mono text-slate-300 uppercase mb-1">
                Next Payment Due Date
              </label>
              <input
                id="crm-due-date"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
              />
            </div>
          </div>

          <div>
            <label htmlFor="crm-deliverables" className="block text-[11px] font-mono text-slate-300 uppercase mb-1">
              Deliverables Scope
            </label>
            <input
              id="crm-deliverables"
              type="text"
              value={deliverablesSummary}
              onChange={(e) => setDeliverablesSummary(e.target.value)}
              placeholder="e.g. 2x RED 8K Commercial Films, 15x Vertical Reels, Meta Ad Scaling"
              className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 rounded-lg text-xs font-mono text-slate-400 hover:text-white bg-slate-900 border border-slate-700 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmittingClient}
              className="px-5 py-2 rounded-lg text-xs font-bold text-white bg-sky-600 hover:bg-sky-500 transition-colors cursor-pointer"
            >
              {isSubmittingClient ? 'Saving Client...' : 'Save Client to CRM'}
            </button>
          </div>
        </form>
      )}

      {/* Client Accounts & Payment CRM List */}
      <div className="space-y-4">
        {filteredClients.map((client) => {
          const cleanPhone = client.phone.replace(/[^\d]/g, '');
          const waPhone = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
          const waReminderText = encodeURIComponent(
            `Hello ${client.clientName} (${client.companyName}),\n\nGreetings from *Booms Mumbai Studio*! Here is your current account & payment summary:\n• Package: ${client.servicePackage}\n• Total Contract: ${formatINR(client.totalContractValue)} (+18% GST: ${formatINR(client.gstAmount)})\n• Amount Paid: ${formatINR(client.paidAmount)}\n• *Pending Balance: ${formatINR(client.pendingAmount)}*\n• Due Date: ${client.dueDate}\n\nPlease let us know once the installment is processed. Thank you!`
          );

          return (
            <div
              key={client.id}
              className="bg-[#0e1320] border border-slate-800 hover:border-slate-700 rounded-xl p-5 space-y-4 shadow-lg transition-all"
            >
              {/* Top Row: Client Identity & Payment Status */}
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h4 className="text-base font-bold text-white font-display flex items-center gap-1.5">
                      <Building2 className="w-4 h-4 text-sky-400" />
                      <span>{client.companyName}</span>
                    </h4>
                    <span
                      className={`text-[10px] font-mono uppercase px-2.5 py-0.5 rounded-full font-bold border ${
                        client.paymentStatus === 'Paid'
                          ? 'bg-emerald-950/80 text-emerald-400 border-emerald-700'
                          : client.paymentStatus === 'Partial'
                          ? 'bg-sky-950/80 text-sky-400 border-sky-700'
                          : 'bg-rose-950/80 text-rose-400 border-rose-700'
                      }`}
                    >
                      {client.paymentStatus}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400 bg-[#090d16] px-2 py-0.5 rounded border border-slate-800">
                      {client.servicePackage}
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 mt-1 flex flex-wrap items-center gap-3">
                    <span>Contact: <strong className="text-slate-200">{client.clientName}</strong></span>
                    <span className="flex items-center gap-1 font-mono text-sky-400">
                      <Phone className="w-3 h-3" />
                      {client.phone}
                    </span>
                    <span className="flex items-center gap-1">
                      <Mail className="w-3 h-3" />
                      {client.email}
                    </span>
                    {client.gstNumber && (
                      <span className="font-mono text-[11px] text-slate-400">
                        GSTIN: {client.gstNumber}
                      </span>
                    )}
                  </div>
                </div>

                {/* Project Status Selector & Actions */}
                <div className="flex flex-wrap items-center gap-2">
                  <select
                    aria-label={`Project status for ${client.companyName}`}
                    value={client.projectStatus}
                    onChange={(e) => handleUpdateProjectStatus(client.id, e.target.value)}
                    className="bg-[#090d16] border border-slate-700 text-xs text-white rounded-lg px-2.5 py-1.5 font-mono cursor-pointer"
                  >
                    <option value="Onboarding">Onboarding</option>
                    <option value="Active Campaign">Active Campaign</option>
                    <option value="In Production">In Production</option>
                    <option value="Completed">Completed</option>
                  </select>

                  <button
                    type="button"
                    onClick={() => {
                      soundFx.playClick(840);
                      setActivePaymentClientId(
                        activePaymentClientId === client.id ? null : client.id
                      );
                      setPaymentAmount(String(client.pendingAmount || 50000));
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-[#0F172A] hover:bg-slate-800 border border-sky-500/50 cursor-pointer"
                  >
                    <CreditCard className="w-3.5 h-3.5 text-sky-400" />
                    <span>+ Record Payment</span>
                  </button>

                  <a
                    href={`https://wa.me/${waPhone}?text=${waReminderText}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-emerald-300 bg-emerald-950/60 hover:bg-emerald-900/70 border border-emerald-700/60"
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                    <span>WhatsApp Invoice</span>
                  </a>

                  <button
                    type="button"
                    onClick={() => handleDeleteClient(client.id)}
                    aria-label={`Delete client ${client.companyName}`}
                    className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded-lg cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Financial Breakdown Row */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#090d16] p-3.5 rounded-xl border border-slate-800/90">
                <div>
                  <span className="text-[10px] font-mono uppercase text-slate-400 block">
                    Contract Value
                  </span>
                  <span className="text-sm font-mono font-bold text-white">
                    {formatINR(client.totalContractValue)}
                  </span>
                </div>

                <div>
                  <span className="text-[10px] font-mono uppercase text-slate-400 block">
                    Paid Amount
                  </span>
                  <span className="text-sm font-mono font-bold text-emerald-400">
                    {formatINR(client.paidAmount)}
                  </span>
                </div>

                <div>
                  <span className="text-[10px] font-mono uppercase text-slate-400 block">
                    Pending Balance
                  </span>
                  <span className="text-sm font-mono font-bold text-rose-400">
                    {formatINR(client.pendingAmount)}
                  </span>
                </div>

                <div>
                  <span className="text-[10px] font-mono uppercase text-slate-400 block">
                    18% GST · Due Date
                  </span>
                  <span className="text-xs font-mono text-sky-400">
                    {formatINR(client.gstAmount)} · {client.dueDate}
                  </span>
                </div>
              </div>

              {/* Inline Record Payment Drawer */}
              {activePaymentClientId === client.id && (
                <div className="bg-[#0F172A] border border-sky-500/50 rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      <IndianRupee className="w-3.5 h-3.5 text-sky-400" />
                      Record Payment Installment for {client.companyName}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400">
                      Current Pending: {formatINR(client.pendingAmount)}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                    <input
                      type="number"
                      value={paymentAmount}
                      onChange={(e) => setPaymentAmount(e.target.value)}
                      placeholder="Amount (INR)"
                      className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
                    />
                    <select
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value as any)}
                      className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                    >
                      <option value="UPI">UPI</option>
                      <option value="NEFT/RTGS">NEFT / RTGS</option>
                      <option value="Razorpay">Razorpay</option>
                      <option value="Cheque">Cheque</option>
                    </select>
                    <input
                      type="text"
                      value={paymentRef}
                      onChange={(e) => setPaymentRef(e.target.value)}
                      placeholder="UTR / Txn Reference"
                      className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
                    />
                    <button
                      type="button"
                      disabled={isRecordingPayment}
                      onClick={() => handleRecordPayment(client.id)}
                      className="px-4 py-2 rounded-lg text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 cursor-pointer"
                    >
                      {isRecordingPayment ? 'Recording...' : 'Confirm Payment'}
                    </button>
                  </div>
                </div>
              )}

              {/* Deliverables, Payment History & Embedded Formula Snapshots */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-400">
                <div>
                  <strong className="text-slate-300">Scope:</strong> {client.deliverablesSummary}
                </div>
                <div className="font-mono text-[11px] flex items-center gap-1 text-slate-400">
                  <Calendar className="w-3 h-3 text-sky-400" />
                  <span>Lead: {client.assignedLead}</span>
                </div>
              </div>

              {client.payments && client.payments.length > 0 && (
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <span className="text-[11px] font-mono text-slate-400">Transactions:</span>
                  {client.payments.map((p) => (
                    <span
                      key={p.id}
                      className="text-[11px] font-mono bg-[#090d16] border border-slate-800 px-2.5 py-0.5 rounded text-emerald-300"
                    >
                      +{formatINR(p.amount)} via {p.method} ({p.referenceNo}) on {p.date}
                    </span>
                  ))}
                </div>
              )}

              {client.formulaSnapshots && client.formulaSnapshots.length > 0 && (
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <span className="text-[11px] font-mono text-sky-400 flex items-center gap-1">
                    <Calculator className="w-3 h-3" />
                    Embedded Formulas:
                  </span>
                  {client.formulaSnapshots.map((s) => (
                    <span
                      key={s.id}
                      className="text-[11px] font-mono bg-[#0F172A] border border-sky-500/40 px-2.5 py-0.5 rounded text-slate-200"
                    >
                      [{s.type}] {s.summary}
                    </span>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
