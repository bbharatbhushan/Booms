import React, { useState } from 'react';
import {
  Calculator,
  TrendingUp,
  Share2,
  Clapperboard,
  CheckCircle2,
  BookmarkPlus,
  Sparkles,
} from 'lucide-react';
import { CrmClient } from '../../types';
import {
  calculateDigitalMarketingFormulas,
  calculateSocialMediaFormulas,
  calculateProductionFormulas,
  formatINR,
} from '../../utils/campaignCalculator';
import { soundFx } from '../../utils/soundEffects';

interface MarketingFormulasTabProps {
  clients: CrmClient[];
  onRefreshClients: () => void;
  onUpdateExportFormulas?: (
    rows: {
      category: string;
      metricName: string;
      formulaUsed: string;
      calculatedValue: string;
    }[]
  ) => void;
}

export const MarketingFormulasTab: React.FC<MarketingFormulasTabProps> = ({
  clients,
  onRefreshClients,
  onUpdateExportFormulas,
}) => {
  const [selectedClientId, setSelectedClientId] = useState<string>(clients[0]?.id || '');
  const [attachMessage, setAttachMessage] = useState<string | null>(null);
  const [attaching, setAttaching] = useState(false);

  // 1. Digital Marketing Inputs
  const [adSpend, setAdSpend] = useState(250000);
  const [revenueGenerated, setRevenueGenerated] = useState(1200000);
  const [impressions, setImpressions] = useState(1400000);
  const [clicks, setClicks] = useState(35000);
  const [conversions, setConversions] = useState(700);
  const [avgOrderValue, setAvgOrderValue] = useState(2200);
  const [repeatPurchaseFrequency, setRepeatPurchaseFrequency] = useState(3);
  const [grossMarginPercent, setGrossMarginPercent] = useState(62);

  // 2. Social Media & Reels Inputs
  const [followers, setFollowers] = useState(85000);
  const [reach, setReach] = useState(340000);
  const [socialImpressions, setSocialImpressions] = useState(520000);
  const [likes, setLikes] = useState(24000);
  const [comments, setComments] = useState(1850);
  const [shares, setShares] = useState(6400);
  const [saves, setSaves] = useState(7200);
  const [threeSecViews, setThreeSecViews] = useState(225000);
  const [fullVideoWatches, setFullVideoWatches] = useState(92000);
  const [netNewFollowers, setNetNewFollowers] = useState(4600);

  // 3. Video Production & Cinema Inputs
  const [preProductionCost, setPreProductionCost] = useState(65000);
  const [shootDays, setShootDays] = useState(2);
  const [cameraGearDailyRate, setCameraGearDailyRate] = useState(45000);
  const [soundstageDailyRate, setSoundstageDailyRate] = useState(35000);
  const [crewDailyRate, setCrewDailyRate] = useState(30000);
  const [editingVfxCost, setEditingVfxCost] = useState(40000);
  const [colorGradingSoundCost, setColorGradingSoundCost] = useState(25000);
  const [agencyMarginPercent, setAgencyMarginPercent] = useState(20);
  const [totalFinishedMinutes, setTotalFinishedMinutes] = useState(3);
  const [deliverablesReelsCount, setDeliverablesReelsCount] = useState(12);

  const dmResult = calculateDigitalMarketingFormulas({
    adSpend,
    revenueGenerated,
    impressions,
    clicks,
    conversions,
    avgOrderValue,
    repeatPurchaseFrequency,
    grossMarginPercent,
  });

  const smResult = calculateSocialMediaFormulas({
    followers,
    reach,
    impressions: socialImpressions,
    likes,
    comments,
    shares,
    saves,
    threeSecViews,
    fullVideoWatches,
    netNewFollowers,
  });

  const prodResult = calculateProductionFormulas({
    preProductionCost,
    shootDays,
    cameraGearDailyRate,
    soundstageDailyRate,
    crewDailyRate,
    editingVfxCost,
    colorGradingSoundCost,
    agencyMarginPercent,
    totalFinishedMinutes,
    deliverablesReelsCount,
  });

  // Sync calculated rows up to parent if callback provided
  React.useEffect(() => {
    if (!onUpdateExportFormulas) return;
    onUpdateExportFormulas([
      {
        category: 'Digital Marketing',
        metricName: 'ROAS (Return on Ad Spend)',
        formulaUsed: 'Revenue / Ad Spend',
        calculatedValue: `${dmResult.roas}x`,
      },
      {
        category: 'Digital Marketing',
        metricName: 'Marketing ROI (%)',
        formulaUsed: '((Revenue - Ad Spend) / Ad Spend) * 100',
        calculatedValue: `${dmResult.roiPercent}%`,
      },
      {
        category: 'Digital Marketing',
        metricName: 'CPA / CAC (Cost Per Acquisition)',
        formulaUsed: 'Ad Spend / Conversions',
        calculatedValue: formatINR(dmResult.cpa),
      },
      {
        category: 'Digital Marketing',
        metricName: 'CPM (Cost Per 1,000 Impressions)',
        formulaUsed: '(Ad Spend / Impressions) * 1000',
        calculatedValue: formatINR(dmResult.cpm),
      },
      {
        category: 'Digital Marketing',
        metricName: 'CPC & CTR (%)',
        formulaUsed: 'Ad Spend / Clicks & (Clicks / Impressions) * 100',
        calculatedValue: `₹${dmResult.cpc} | ${dmResult.ctrPercent}%`,
      },
      {
        category: 'Digital Marketing',
        metricName: 'Customer LTV & LTV:CAC Ratio',
        formulaUsed: '(AOV * Freq * Gross Margin) / CAC',
        calculatedValue: `${formatINR(dmResult.ltvValue)} (${dmResult.ltvToCacRatio}:1)`,
      },
      {
        category: 'Social Media Management',
        metricName: 'Engagement Rate by Reach (ERR %)',
        formulaUsed: '((Likes + Comments + Shares + Saves) / Reach) * 100',
        calculatedValue: `${smResult.engagementRateByReach}%`,
      },
      {
        category: 'Social Media Management',
        metricName: '3-Sec Video Hook Rate (%)',
        formulaUsed: '(3-Second Views / Impressions) * 100',
        calculatedValue: `${smResult.hookRate3Sec}%`,
      },
      {
        category: 'Social Media Management',
        metricName: 'Reel Hold / Completion Rate (%)',
        formulaUsed: '(Full Watches / 3-Second Views) * 100',
        calculatedValue: `${smResult.holdRateCompletion}%`,
      },
      {
        category: 'Social Media Management',
        metricName: 'Viral Coefficient (K-Factor)',
        formulaUsed: '(Shares / Reach) * (1 + Saves / Reach) * 12',
        calculatedValue: String(smResult.viralCoefficientK),
      },
      {
        category: 'Video Production',
        metricName: 'Base Production Cost (Pre + Shoot + Post)',
        formulaUsed: 'Pre-Prod + (Days * Daily Studio/Gear/Crew) + Post-Prod',
        calculatedValue: formatINR(prodResult.baseProductionCost),
      },
      {
        category: 'Video Production',
        metricName: 'Grand Total with Agency Margin & 18% GST',
        formulaUsed: '(Base + Margin) * 1.18',
        calculatedValue: formatINR(prodResult.grandTotalWithGst),
      },
      {
        category: 'Video Production',
        metricName: 'Cost Per Viral Reel Deliverable',
        formulaUsed: 'Grand Total / Total Reels Extracted',
        calculatedValue: formatINR(prodResult.costPerViralReel),
      },
    ]);
  }, [
    dmResult.roas,
    dmResult.roiPercent,
    dmResult.cpa,
    dmResult.cpm,
    dmResult.cpc,
    dmResult.ctrPercent,
    dmResult.ltvValue,
    dmResult.ltvToCacRatio,
    smResult.engagementRateByReach,
    smResult.hookRate3Sec,
    smResult.holdRateCompletion,
    smResult.viralCoefficientK,
    prodResult.baseProductionCost,
    prodResult.grandTotalWithGst,
    prodResult.costPerViralReel,
    onUpdateExportFormulas,
  ]);

  const handleAttachFormulaToClient = async (
    type: 'Digital Marketing' | 'Social Media' | 'Video Production'
  ) => {
    const targetId = selectedClientId || clients[0]?.id;
    if (!targetId) return;

    setAttaching(true);
    setAttachMessage(null);

    let summary = '';
    let metrics: Record<string, string | number> = {};

    if (type === 'Digital Marketing') {
      summary = `ROAS: ${dmResult.roas}x · ROI: ${dmResult.roiPercent}% · CPA: ${formatINR(dmResult.cpa)} · LTV:CAC ${dmResult.ltvToCacRatio}:1`;
      metrics = { ...dmResult };
    } else if (type === 'Social Media') {
      summary = `ERR: ${smResult.engagementRateByReach}% · Hook: ${smResult.hookRate3Sec}% · Hold: ${smResult.holdRateCompletion}% · Growth: +${smResult.monthlyFollowerGrowthRate}%`;
      metrics = { ...smResult };
    } else {
      summary = `Total Quote (incl. 18% GST): ${formatINR(prodResult.grandTotalWithGst)} · Cost/Reel: ${formatINR(prodResult.costPerViralReel)}`;
      metrics = { ...prodResult };
    }

    try {
      const res = await fetch(`/api/crm/clients/${targetId}/formula-snapshot`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, summary, metrics }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        soundFx.playClick(940);
        setAttachMessage(data.message);
        onRefreshClients();
      }
    } catch {
      // Handled gracefully
    } finally {
      setAttaching(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Client Link Bar: Embed Formulas into Any CRM Client */}
      <div className="bg-[#0F172A] border border-sky-500/40 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-lg">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-sky-400">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Client-Embedded Formula Engine</span>
          </div>
          <h4 className="text-sm sm:text-base font-bold text-white font-display mt-0.5">
            Calculate &amp; Embed Marketing, Social &amp; Production Formulas into Client CRM
          </h4>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <label htmlFor="formula-client-select" className="text-xs font-mono text-slate-300">
            Select CRM Client:
          </label>
          <select
            id="formula-client-select"
            value={selectedClientId}
            onChange={(e) => setSelectedClientId(e.target.value)}
            className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
          >
            {clients.map((c) => (
              <option key={c.id} value={c.id}>
                {c.companyName} ({c.clientName})
              </option>
            ))}
          </select>
        </div>
      </div>

      {attachMessage && (
        <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-700 text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{attachMessage}</span>
        </div>
      )}

      {/* 3-Column Formula Suite Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* 1. DIGITAL MARKETING & PAID ADS FORMULA CALCULATOR */}
        <div className="bg-[#0e1320] border border-slate-800 rounded-xl p-5 flex flex-col justify-between space-y-5 shadow-lg">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-sky-400" />
                <h5 className="text-sm font-bold text-white font-display">
                  1. Digital Marketing &amp; Paid Ads
                </h5>
              </div>
              <span className="text-[10px] font-mono text-sky-400 bg-[#0F172A] px-2 py-0.5 rounded border border-slate-700">
                ROAS · CAC · LTV
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2.5 text-xs">
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  Ad Spend (INR)
                </label>
                <input
                  type="number"
                  value={adSpend}
                  onChange={(e) => setAdSpend(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  Revenue Generated (INR)
                </label>
                <input
                  type="number"
                  value={revenueGenerated}
                  onChange={(e) => setRevenueGenerated(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  Total Impressions
                </label>
                <input
                  type="number"
                  value={impressions}
                  onChange={(e) => setImpressions(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  Link Clicks
                </label>
                <input
                  type="number"
                  value={clicks}
                  onChange={(e) => setClicks(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  Conversions / Orders
                </label>
                <input
                  type="number"
                  value={conversions}
                  onChange={(e) => setConversions(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  Avg Order Value (INR)
                </label>
                <input
                  type="number"
                  value={avgOrderValue}
                  onChange={(e) => setAvgOrderValue(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
            </div>

            {/* Live Formula Output Rows */}
            <div className="bg-[#090d16] border border-slate-800 rounded-xl p-3.5 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">
                  ROAS <code className="text-[10px] text-slate-500">(Rev ÷ Spend)</code>
                </span>
                <span className="font-mono font-bold text-sky-400">{dmResult.roas}x</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">
                  Net ROI % <code className="text-[10px] text-slate-500">((Rev-Spend)÷Spend)</code>
                </span>
                <span className="font-mono font-bold text-emerald-400">+{dmResult.roiPercent}%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">
                  CPA / CAC <code className="text-[10px] text-slate-500">(Spend ÷ Conv)</code>
                </span>
                <span className="font-mono font-bold text-white">{formatINR(dmResult.cpa)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">
                  CPM &amp; CPC <code className="text-[10px] text-slate-500">(Per 1K / Click)</code>
                </span>
                <span className="font-mono text-slate-200">
                  {formatINR(dmResult.cpm)} · ₹{dmResult.cpc}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">
                  CTR % &amp; CVR % <code className="text-[10px] text-slate-500">(Funnel)</code>
                </span>
                <span className="font-mono text-sky-400">
                  {dmResult.ctrPercent}% CTR · {dmResult.cvrPercent}% CVR
                </span>
              </div>
              <div className="flex items-center justify-between pt-1 border-t border-slate-800">
                <span className="text-slate-400">Customer LTV : CAC Ratio</span>
                <span className="font-mono font-bold text-emerald-400">
                  {formatINR(dmResult.ltvValue)} ({dmResult.ltvToCacRatio}:1)
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            disabled={attaching}
            onClick={() => handleAttachFormulaToClient('Digital Marketing')}
            className="w-full flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-xs font-semibold text-white bg-[#0F172A] hover:bg-slate-800 border border-sky-500/40 cursor-pointer"
          >
            <BookmarkPlus className="w-3.5 h-3.5 text-sky-400" />
            <span>Embed Digital Marketing KPIs to Client</span>
          </button>
        </div>

        {/* 2. SOCIAL MEDIA MANAGEMENT & VIRAL REELS FORMULA CALCULATOR */}
        <div className="bg-[#0e1320] border border-slate-800 rounded-xl p-5 flex flex-col justify-between space-y-5 shadow-lg">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Share2 className="w-4 h-4 text-sky-400" />
                <h5 className="text-sm font-bold text-white font-display">
                  2. Social Media &amp; Viral Reels
                </h5>
              </div>
              <span className="text-[10px] font-mono text-sky-400 bg-[#0F172A] px-2 py-0.5 rounded border border-slate-700">
                ER% · Hook · K-Factor
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2.5 text-xs">
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  Total Followers
                </label>
                <input
                  type="number"
                  value={followers}
                  onChange={(e) => setFollowers(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  Unique Reach
                </label>
                <input
                  type="number"
                  value={reach}
                  onChange={(e) => setReach(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  Likes + Comments
                </label>
                <input
                  type="number"
                  value={likes}
                  onChange={(e) => setLikes(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  Shares + Saves
                </label>
                <input
                  type="number"
                  value={shares}
                  onChange={(e) => setShares(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  3-Sec Reel Views
                </label>
                <input
                  type="number"
                  value={threeSecViews}
                  onChange={(e) => setThreeSecViews(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  Full Reel Completions
                </label>
                <input
                  type="number"
                  value={fullVideoWatches}
                  onChange={(e) => setFullVideoWatches(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
            </div>

            {/* Live Formula Output Rows */}
            <div className="bg-[#090d16] border border-slate-800 rounded-xl p-3.5 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">
                  Engagement by Reach <code className="text-[10px] text-slate-500">(Eng ÷ Reach)</code>
                </span>
                <span className="font-mono font-bold text-sky-400">
                  {smResult.engagementRateByReach}%
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">
                  Engagement by Followers <code className="text-[10px] text-slate-500">(Eng ÷ Fol)</code>
                </span>
                <span className="font-mono font-bold text-emerald-400">
                  {smResult.engagementRateByFollowers}%
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">
                  3-Sec Hook Rate <code className="text-[10px] text-slate-500">(3s ÷ Imp)</code>
                </span>
                <span className="font-mono font-bold text-white">{smResult.hookRate3Sec}%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">
                  Hold / Completion Rate <code className="text-[10px] text-slate-500">(Full ÷ 3s)</code>
                </span>
                <span className="font-mono text-sky-400">{smResult.holdRateCompletion}%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">
                  Viral K-Factor &amp; Growth %
                </span>
                <span className="font-mono text-emerald-400">
                  K={smResult.viralCoefficientK} · +{smResult.monthlyFollowerGrowthRate}%
                </span>
              </div>
              <div className="flex items-center justify-between pt-1 border-t border-slate-800">
                <span className="text-slate-400">Algorithmic Reach Projection</span>
                <span className="font-mono font-bold text-white">
                  {smResult.estimatedOrganicImpressions.toLocaleString('en-IN')} views
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            disabled={attaching}
            onClick={() => handleAttachFormulaToClient('Social Media')}
            className="w-full flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-xs font-semibold text-white bg-[#0F172A] hover:bg-slate-800 border border-sky-500/40 cursor-pointer"
          >
            <BookmarkPlus className="w-3.5 h-3.5 text-sky-400" />
            <span>Embed Social Media KPIs to Client</span>
          </button>
        </div>

        {/* 3. VIDEO & CINEMA PRODUCTION BUDGETING & FORMULA CALCULATOR */}
        <div className="bg-[#0e1320] border border-slate-800 rounded-xl p-5 flex flex-col justify-between space-y-5 shadow-lg">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Clapperboard className="w-4 h-4 text-sky-400" />
                <h5 className="text-sm font-bold text-white font-display">
                  3. Video &amp; Cinema Production
                </h5>
              </div>
              <span className="text-[10px] font-mono text-sky-400 bg-[#0F172A] px-2 py-0.5 rounded border border-slate-700">
                Shoot · Post · 18% GST
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2.5 text-xs">
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  Pre-Production (INR)
                </label>
                <input
                  type="number"
                  value={preProductionCost}
                  onChange={(e) => setPreProductionCost(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  Shoot Days Count
                </label>
                <input
                  type="number"
                  value={shootDays}
                  onChange={(e) => setShootDays(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  Camera Rig / Day (INR)
                </label>
                <input
                  type="number"
                  value={cameraGearDailyRate}
                  onChange={(e) => setCameraGearDailyRate(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  Stage + Crew / Day (INR)
                </label>
                <input
                  type="number"
                  value={soundstageDailyRate}
                  onChange={(e) => setSoundstageDailyRate(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  Post-Prod &amp; VFX (INR)
                </label>
                <input
                  type="number"
                  value={editingVfxCost}
                  onChange={(e) => setEditingVfxCost(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">
                  Reels Extracted
                </label>
                <input
                  type="number"
                  value={deliverablesReelsCount}
                  onChange={(e) => setDeliverablesReelsCount(Number(e.target.value))}
                  className="w-full bg-[#090d16] border border-slate-700 rounded px-2.5 py-1.5 text-white font-mono"
                />
              </div>
            </div>

            {/* Live Formula Output Rows */}
            <div className="bg-[#090d16] border border-slate-800 rounded-xl p-3.5 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">
                  Shoot Days Burn <code className="text-[10px] text-slate-500">({shootDays}d × Kit)</code>
                </span>
                <span className="font-mono text-white">
                  {formatINR(prodResult.shootDaysTotalCost)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">
                  Base Production + Post
                </span>
                <span className="font-mono text-slate-200">
                  {formatINR(prodResult.baseProductionCost)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">
                  Agency Margin ({agencyMarginPercent}%)
                </span>
                <span className="font-mono text-sky-400">
                  +{formatINR(prodResult.agencyMarginAmount)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">
                  18% GST Tax Component
                </span>
                <span className="font-mono text-slate-300">
                  +{formatINR(prodResult.gstAmount18)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">
                  Cost Per Viral Reel ({deliverablesReelsCount}x)
                </span>
                <span className="font-mono text-emerald-400">
                  {formatINR(prodResult.costPerViralReel)} / reel
                </span>
              </div>
              <div className="flex items-center justify-between pt-1 border-t border-slate-800">
                <span className="text-slate-300 font-semibold">Grand Total Quote (incl. GST)</span>
                <span className="font-mono font-bold text-sky-400 text-sm">
                  {formatINR(prodResult.grandTotalWithGst)}
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            disabled={attaching}
            onClick={() => handleAttachFormulaToClient('Video Production')}
            className="w-full flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-xs font-semibold text-white bg-[#0F172A] hover:bg-slate-800 border border-sky-500/40 cursor-pointer"
          >
            <BookmarkPlus className="w-3.5 h-3.5 text-sky-400" />
            <span>Embed Production Quote to Client</span>
          </button>
        </div>
      </div>

      {/* Formula Reference Cheat-Sheet Footer */}
      <div className="bg-[#090d16] border border-slate-800 rounded-xl p-4 text-xs text-slate-400 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Calculator className="w-4 h-4 text-sky-400 shrink-0" />
          <span>
            All 13 calculated KPIs &amp; formulas are automatically synced with the{' '}
            <strong className="text-white">Google Sheets Report Exporter</strong>.
          </span>
        </div>
        <span className="font-mono text-[11px] text-sky-400">
          ROAS · CAC · LTV · ERR% · Hook% · Hold% · K-Factor · 18% GST Production Ledger
        </span>
      </div>
    </div>
  );
};
