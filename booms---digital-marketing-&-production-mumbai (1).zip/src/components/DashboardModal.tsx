import React, { useState, useEffect, useCallback } from 'react';
import {
  X,
  Plus,
  Trash2,
  CheckCircle,
  RefreshCw,
  Instagram,
  Users,
  BarChart3,
  AlertCircle,
  Film,
  Sparkles,
  Phone,
  Mail,
  Calendar,
  Video,
  Briefcase,
  Calculator,
  ShieldCheck,
  Lock,
} from 'lucide-react';
import { CrmClient, InstagramFeedItem, LeadItem, PortfolioProject } from '../types';
import { soundFx } from '../utils/soundEffects';
import { AdminWhatsappOtpLogin, AdminSession } from './admin/AdminWhatsappOtpLogin';
import { ClientsPaymentCrmTab } from './admin/ClientsPaymentCrmTab';
import { MarketingFormulasTab } from './admin/MarketingFormulasTab';
import { GoogleSheetsExportBar } from './admin/GoogleSheetsExportBar';

export type DashboardTabType =
  | 'clients-crm'
  | 'formulas'
  | 'videos'
  | 'feeds'
  | 'leads'
  | 'stats';

interface DashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  projects?: PortfolioProject[];
  onRefreshProjects?: () => void;
  feeds: InstagramFeedItem[];
  onRefreshFeeds: () => void;
  defaultTab?: DashboardTabType;
}

const DEFAULT_FORMULA_EXPORT_ROWS = [
  {
    category: 'Digital Marketing',
    metricName: 'ROAS (Return on Ad Spend)',
    formulaUsed: 'Revenue / Ad Spend',
    calculatedValue: '4.8x',
  },
  {
    category: 'Digital Marketing',
    metricName: 'Marketing ROI (%)',
    formulaUsed: '((Revenue - Ad Spend) / Ad Spend) * 100',
    calculatedValue: '380%',
  },
  {
    category: 'Digital Marketing',
    metricName: 'CPA / CAC (Cost Per Acquisition)',
    formulaUsed: 'Ad Spend / Conversions',
    calculatedValue: '₹357',
  },
  {
    category: 'Social Media Management',
    metricName: 'Engagement Rate by Reach (ERR %)',
    formulaUsed: '((Likes + Comments + Shares + Saves) / Reach) * 100',
    calculatedValue: '11.6%',
  },
  {
    category: 'Social Media Management',
    metricName: '3-Sec Video Hook Rate (%)',
    formulaUsed: '(3-Second Views / Impressions) * 100',
    calculatedValue: '43.3%',
  },
  {
    category: 'Video Production',
    metricName: 'Grand Total Production Quote (incl. 18% GST)',
    formulaUsed: '(Pre-Prod + Shoot Days + Post + 20% Margin) * 1.18',
    calculatedValue: '₹4,95,600',
  },
];

export const DashboardModal: React.FC<DashboardModalProps> = ({
  isOpen,
  onClose,
  projects = [],
  onRefreshProjects = () => {},
  feeds,
  onRefreshFeeds,
  defaultTab = 'clients-crm',
}) => {
  const [adminSession, setAdminSession] = useState<AdminSession | null>(null);
  const [activeTab, setActiveTab] = useState<DashboardTabType>(defaultTab);

  useEffect(() => {
    setActiveTab(defaultTab);
  }, [defaultTab]);

  // CRM Clients State
  const [crmClients, setCrmClients] = useState<CrmClient[]>([]);
  // Formula Export Rows for Google Sheets
  const [exportFormulas, setExportFormulas] = useState(DEFAULT_FORMULA_EXPORT_ROWS);

  // Form State for Adding New Video/Project to 3D Stage
  const [projectTitle, setProjectTitle] = useState('');
  const [projectClient, setProjectClient] = useState('');
  const [projectCategory, setProjectCategory] = useState('Commercial Film');
  const [projectVideoUrl, setProjectVideoUrl] = useState('');
  const [projectTagline, setProjectTagline] = useState('');
  const [projectDescription, setProjectDescription] = useState('');
  const [isSubmittingProject, setIsSubmittingProject] = useState(false);
  const [projectMessage, setProjectMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  // Form State for Adding New Client Instagram Feed
  const [clientName, setClientName] = useState('');
  const [instagramHandle, setInstagramHandle] = useState('');
  const [postUrl, setPostUrl] = useState('');
  const [mediaType, setMediaType] = useState<'reel' | 'post'>('reel');
  const [caption, setCaption] = useState('');
  const [viewsCount, setViewsCount] = useState('1.2M');
  const [likesCount, setLikesCount] = useState('85K');
  const [commentsCount, setCommentsCount] = useState('420');
  const [selectedThumb, setSelectedThumb] = useState(
    '/src/assets/images/hero_booms_studio_1794348322633.jpg'
  );
  const [isSubmittingFeed, setIsSubmittingFeed] = useState(false);
  const [feedMessage, setFeedMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  // Leads State
  const [leads, setLeads] = useState<LeadItem[]>([]);
  const [loadingLeads, setLoadingLeads] = useState(false);

  // Studio Stats State
  const [stats, setStats] = useState<any>(null);

  const fetchCrmClients = useCallback(async () => {
    try {
      const res = await fetch('/api/crm/clients');
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        setCrmClients(data.data);
      }
    } catch {
      // Keep fallback
    }
  }, []);

  const fetchLeads = useCallback(async () => {
    setLoadingLeads(true);
    try {
      const res = await fetch('/api/leads');
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        setLeads(data.data);
      }
    } catch {
      // Keep existing leads
    } finally {
      setLoadingLeads(false);
    }
  }, []);

  const fetchStats = useCallback(async () => {
    try {
      const res = await fetch('/api/stats');
      const data = await res.json();
      if (data.success) {
        setStats(data.data);
      }
    } catch {
      // Handled gracefully
    }
  }, []);

  useEffect(() => {
    if (isOpen && adminSession) {
      fetchCrmClients();
      fetchLeads();
      fetchStats();
    }
  }, [isOpen, adminSession, fetchCrmClients, fetchLeads, fetchStats]);

  if (!isOpen) return null;

  // Handle Adding Video to 3D Stage & Portfolio
  const handleAddProjectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!projectTitle.trim() || !projectVideoUrl.trim()) {
      setProjectMessage({
        type: 'error',
        text: 'Please provide both Project Title and Video URL or Link',
      });
      return;
    }

    setIsSubmittingProject(true);
    setProjectMessage(null);

    try {
      const res = await fetch('/api/portfolio-projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: projectTitle.trim(),
          client: projectClient.trim() || 'Booms Brand Partner',
          category: projectCategory,
          videoUrl: projectVideoUrl.trim(),
          tagline: projectTagline.trim() || 'Produced and scaled by Booms Mumbai Studio',
          description:
            projectDescription.trim() ||
            'High-end cinema production engineered for viral retention and measurable business growth.',
        }),
      });

      const data = await res.json();
      if (data.success) {
        soundFx.playBoom();
        setProjectMessage({
          type: 'success',
          text: 'Video added! It is now live on the Interactive 3D Stage and Portfolio!',
        });
        setProjectTitle('');
        setProjectClient('');
        setProjectVideoUrl('');
        setProjectTagline('');
        setProjectDescription('');
        onRefreshProjects();
        onRefreshFeeds();
      } else {
        setProjectMessage({ type: 'error', text: data.error || 'Failed to add project' });
      }
    } catch {
      setProjectMessage({ type: 'error', text: 'Network error connecting to backend' });
    } finally {
      setIsSubmittingProject(false);
    }
  };

  const handleDeleteProject = async (id: string) => {
    soundFx.playClick(500);
    try {
      const res = await fetch(`/api/portfolio-projects/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        onRefreshProjects();
      }
    } catch {
      // Handled
    }
  };

  const handleAddFeedSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName.trim() || !instagramHandle.trim()) {
      setFeedMessage({
        type: 'error',
        text: 'Please fill in client name and Instagram handle',
      });
      return;
    }

    setIsSubmittingFeed(true);
    setFeedMessage(null);

    try {
      const res = await fetch('/api/instagram-feeds', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientName: clientName.trim(),
          instagramHandle: instagramHandle.trim(),
          postUrl: postUrl.trim() || `https://instagram.com/${instagramHandle.replace('@', '')}`,
          mediaType,
          caption: caption.trim() || 'Produced and scaled by Booms Mumbai Studio',
          viewsCount,
          likesCount,
          commentsCount,
          thumbnailUrl: selectedThumb,
          tags: ['#BoomsViral', '#ClientCampaign', '#MumbaiProduction'],
        }),
      });

      const data = await res.json();
      if (data.success) {
        soundFx.playBoom();
        setFeedMessage({
          type: 'success',
          text: 'Feed published successfully to portfolio!',
        });
        setClientName('');
        setInstagramHandle('');
        setPostUrl('');
        setCaption('');
        onRefreshFeeds();
      } else {
        setFeedMessage({ type: 'error', text: data.error || 'Failed to add feed' });
      }
    } catch {
      setFeedMessage({ type: 'error', text: 'Network error connecting to backend' });
    } finally {
      setIsSubmittingFeed(false);
    }
  };

  const handleDeleteFeed = async (id: string) => {
    soundFx.playClick(500);
    try {
      const res = await fetch(`/api/instagram-feeds/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        onRefreshFeeds();
      }
    } catch {
      // Handled
    }
  };

  const handleUpdateLeadStatus = async (leadId: string, newStatus: string) => {
    try {
      const res = await fetch(`/api/leads/${leadId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      const data = await res.json();
      if (data.success) {
        setLeads((prev) =>
          prev.map((l) => (l.id === leadId ? { ...l, status: newStatus as any } : l))
        );
      }
    } catch {
      // Handled
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-5 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-6xl bg-[#0b0f19] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden max-h-[94vh] flex flex-col">
        {/* Top Admin Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#0d121f]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#0F172A] border border-slate-700 flex items-center justify-center text-sky-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-white font-display">
                  Booms Admin Panel · Clients, Payments CRM &amp; Studio Dashboard
                </h3>
                {adminSession ? (
                  <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-700/70">
                    WhatsApp OTP Verified ({adminSession.phone})
                  </span>
                ) : (
                  <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-slate-800 text-sky-400 border border-slate-700">
                    Admin Auth Required
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                Clients &amp; Payment CRM, Digital Marketing / Social / Production Formula Suite, 3D Stage &amp; Google Sheets Export
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {adminSession && (
              <button
                type="button"
                onClick={() => {
                  soundFx.playClick(650);
                  setAdminSession(null);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono text-slate-300 hover:text-white bg-[#0F172A] border border-slate-700 cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5 text-sky-400" />
                <span>Lock Admin</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => {
                soundFx.playClick(600);
                onClose();
              }}
              aria-label="Close dashboard modal"
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Gate 1: If Admin is not logged in via WhatsApp OTP, show Login Screen */}
        {!adminSession ? (
          <div className="overflow-y-auto flex-1">
            <AdminWhatsappOtpLogin
              onVerified={(session) => setAdminSession(session)}
              onCancel={onClose}
            />
          </div>
        ) : (
          <>
            {/* Top Google Sheets Export & Workspace Bar */}
            <GoogleSheetsExportBar
              payload={{
                clients: crmClients,
                leads,
                formulaMetrics: exportFormulas,
              }}
            />

            {/* Admin Dashboard Tab Navigation */}
            <div className="flex items-center gap-1.5 px-6 pt-3 border-b border-slate-800/80 bg-[#090d16] overflow-x-auto">
              <button
                type="button"
                onClick={() => {
                  soundFx.playClick(700);
                  setActiveTab('clients-crm');
                }}
                className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-lg transition-all cursor-pointer whitespace-nowrap border-b-2 ${
                  activeTab === 'clients-crm'
                    ? 'bg-[#0F172A] text-white border-sky-400'
                    : 'text-slate-400 hover:text-white border-transparent'
                }`}
              >
                <Briefcase className="w-4 h-4 text-sky-400" />
                <span>Clients &amp; Payment CRM ({crmClients.length})</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  soundFx.playClick(700);
                  setActiveTab('formulas');
                }}
                className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-lg transition-all cursor-pointer whitespace-nowrap border-b-2 ${
                  activeTab === 'formulas'
                    ? 'bg-[#0F172A] text-white border-sky-400'
                    : 'text-slate-400 hover:text-white border-transparent'
                }`}
              >
                <Calculator className="w-4 h-4 text-sky-400" />
                <span>Marketing, Social &amp; Production Formulas</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  soundFx.playClick(700);
                  setActiveTab('videos');
                }}
                className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-lg transition-all cursor-pointer whitespace-nowrap border-b-2 ${
                  activeTab === 'videos'
                    ? 'bg-[#0F172A] text-white border-sky-400'
                    : 'text-slate-400 hover:text-white border-transparent'
                }`}
              >
                <Video className="w-4 h-4 text-sky-400" />
                <span>3D Stage Videos ({projects.length})</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  soundFx.playClick(700);
                  setActiveTab('feeds');
                }}
                className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-lg transition-all cursor-pointer whitespace-nowrap border-b-2 ${
                  activeTab === 'feeds'
                    ? 'bg-[#0F172A] text-white border-sky-400'
                    : 'text-slate-400 hover:text-white border-transparent'
                }`}
              >
                <Instagram className="w-4 h-4 text-sky-400" />
                <span>Client Feeds ({feeds.length})</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  soundFx.playClick(700);
                  setActiveTab('leads');
                }}
                className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-lg transition-all cursor-pointer whitespace-nowrap border-b-2 ${
                  activeTab === 'leads'
                    ? 'bg-[#0F172A] text-white border-sky-400'
                    : 'text-slate-400 hover:text-white border-transparent'
                }`}
              >
                <Users className="w-4 h-4 text-sky-400" />
                <span>Inquiries Leads ({leads.length})</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  soundFx.playClick(700);
                  setActiveTab('stats');
                }}
                className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-lg transition-all cursor-pointer whitespace-nowrap border-b-2 ${
                  activeTab === 'stats'
                    ? 'bg-[#0F172A] text-white border-sky-400'
                    : 'text-slate-400 hover:text-white border-transparent'
                }`}
              >
                <BarChart3 className="w-4 h-4 text-sky-400" />
                <span>Studio Analytics</span>
              </button>
            </div>

            {/* Tab Content Body */}
            <div className="p-6 overflow-y-auto flex-1">
              {/* TAB 1: Clients Management & Payment CRM */}
              {activeTab === 'clients-crm' && (
                <ClientsPaymentCrmTab
                  clients={crmClients}
                  onRefreshClients={fetchCrmClients}
                />
              )}

              {/* TAB 2: Digital Marketing, Social Media & Production Formula Suite */}
              {activeTab === 'formulas' && (
                <MarketingFormulasTab
                  clients={crmClients}
                  onRefreshClients={fetchCrmClients}
                  onUpdateExportFormulas={setExportFormulas}
                />
              )}

              {/* TAB 3: 3D Stage Videos & Projects Management */}
              {activeTab === 'videos' && (
                <div className="space-y-8">
                  <div className="bg-[#0e1320] border border-slate-700/70 rounded-xl p-5 shadow-lg">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-sky-400" />
                        <h4 className="text-sm font-bold text-white font-display">
                          Add Video or Link to Interactive 3D Stage
                        </h4>
                      </div>
                      <span className="text-[11px] font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                        Directly syncs to 3D cylinder stage
                      </span>
                    </div>

                    {projectMessage && (
                      <div
                        className={`mb-4 p-3 rounded-lg text-xs font-medium flex items-center gap-2 ${
                          projectMessage.type === 'success'
                            ? 'bg-emerald-950/80 border border-emerald-800 text-emerald-300'
                            : 'bg-rose-950/80 border border-rose-800 text-rose-300'
                        }`}
                      >
                        {projectMessage.type === 'success' ? (
                          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                        )}
                        <span>{projectMessage.text}</span>
                      </div>
                    )}

                    <form onSubmit={handleAddProjectSubmit} className="space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                            Video URL or Link *
                          </label>
                          <input
                            type="text"
                            required
                            value={projectVideoUrl}
                            onChange={(e) => setProjectVideoUrl(e.target.value)}
                            placeholder="https://www.youtube.com/watch?v=... or reel"
                            className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                            Campaign Title *
                          </label>
                          <input
                            type="text"
                            required
                            value={projectTitle}
                            onChange={(e) => setProjectTitle(e.target.value)}
                            placeholder="e.g. Cinematic Music Video IV"
                            className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                            Client / Brand Name
                          </label>
                          <input
                            type="text"
                            value={projectClient}
                            onChange={(e) => setProjectClient(e.target.value)}
                            placeholder="e.g. Illtill Chemist"
                            className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                            Category
                          </label>
                          <select
                            value={projectCategory}
                            onChange={(e) => setProjectCategory(e.target.value)}
                            className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-sky-500 cursor-pointer"
                          >
                            <option value="Commercial Film">Commercial Film</option>
                            <option value="Music Videos">Music Videos</option>
                            <option value="Ads">Ads</option>
                            <option value="Brands &amp; Reels">Brands &amp; Reels</option>
                            <option value="Films">Films</option>
                          </select>
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                            Tagline / Hook
                          </label>
                          <input
                            type="text"
                            value={projectTagline}
                            onChange={(e) => setProjectTagline(e.target.value)}
                            placeholder="e.g. Stunning visual rhythm celebrating nature and city lights"
                            className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
                          />
                        </div>
                      </div>

                      <div className="flex items-center justify-end gap-3 pt-2">
                        <button
                          type="submit"
                          disabled={isSubmittingProject}
                          className="flex items-center gap-1.5 px-5 py-2.5 text-xs font-bold text-white bg-[#0F172A] hover:bg-slate-800 border border-slate-600 hover:border-sky-500 rounded-lg transition-all shadow-md cursor-pointer disabled:opacity-50"
                        >
                          {isSubmittingProject ? (
                            <RefreshCw className="w-3.5 h-3.5 animate-spin text-sky-400" />
                          ) : (
                            <Plus className="w-3.5 h-3.5 text-sky-400" />
                          )}
                          <span>+ Add Video to 3D Stage &amp; Portfolio</span>
                        </button>
                      </div>
                    </form>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-xs font-mono uppercase tracking-wider text-slate-300">
                        Active Projects on Interactive 3D Stage ({projects.length})
                      </h4>
                      <button
                        type="button"
                        onClick={() => onRefreshProjects()}
                        className="flex items-center gap-1 text-[11px] text-sky-400 hover:text-sky-300 font-mono"
                      >
                        <RefreshCw className="w-3 h-3" />
                        <span>Refresh</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                      {projects.map((proj) => (
                        <div
                          key={proj.id}
                          className="bg-[#0e1320] border border-slate-800 hover:border-slate-700 rounded-xl p-3 flex items-start justify-between gap-3 shadow transition-all"
                        >
                          <div className="flex items-start gap-3 min-w-0">
                            <img
                              src={proj.image}
                              alt={proj.title}
                              referrerPolicy="no-referrer"
                              className="w-16 h-12 rounded object-cover border border-slate-700 shrink-0"
                            />
                            <div className="min-w-0">
                              <h5 className="text-xs font-bold text-white truncate font-display">
                                {proj.title}
                              </h5>
                              <div className="text-[11px] text-slate-400 truncate">
                                {proj.client} · {proj.category}
                              </div>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleDeleteProject(proj.id)}
                            title="Delete project from 3D stage"
                            className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded transition-colors cursor-pointer shrink-0"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: Manage Client Feeds */}
              {activeTab === 'feeds' && (
                <div className="space-y-8">
                  <div className="bg-[#0e1320] border border-slate-700/70 rounded-xl p-5 shadow-lg">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-sky-400" />
                        <h4 className="text-sm font-bold text-white font-display">
                          Publish New Client Instagram Feed
                        </h4>
                      </div>
                    </div>

                    {feedMessage && (
                      <div
                        className={`mb-4 p-3 rounded-lg text-xs font-medium flex items-center gap-2 ${
                          feedMessage.type === 'success'
                            ? 'bg-emerald-950/80 border border-emerald-800 text-emerald-300'
                            : 'bg-rose-950/80 border border-rose-800 text-rose-300'
                        }`}
                      >
                        {feedMessage.type === 'success' ? (
                          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                        )}
                        <span>{feedMessage.text}</span>
                      </div>
                    )}

                    <form onSubmit={handleAddFeedSubmit} className="space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                            Client Brand Name *
                          </label>
                          <input
                            type="text"
                            required
                            value={clientName}
                            onChange={(e) => setClientName(e.target.value)}
                            placeholder="e.g. Orbit Beverages"
                            className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                            Instagram Handle *
                          </label>
                          <input
                            type="text"
                            required
                            value={instagramHandle}
                            onChange={(e) => setInstagramHandle(e.target.value)}
                            placeholder="e.g. @orbitbeverages.in"
                            className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                            Format Type
                          </label>
                          <select
                            value={mediaType}
                            onChange={(e) => setMediaType(e.target.value as 'reel' | 'post')}
                            className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                          >
                            <option value="reel">Instagram Reel (Vertical 9:16)</option>
                            <option value="post">Standard Post / Carousel</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                            Instagram Post URL
                          </label>
                          <input
                            type="url"
                            value={postUrl}
                            onChange={(e) => setPostUrl(e.target.value)}
                            placeholder="https://instagram.com/p/..."
                            className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-mono text-slate-400 uppercase mb-1">
                            Campaign Caption / Hook
                          </label>
                          <input
                            type="text"
                            value={caption}
                            onChange={(e) => setCaption(e.target.value)}
                            placeholder="e.g. 1000fps citrus splash commercial shoot..."
                            className="w-full bg-[#090d16] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                          />
                        </div>
                      </div>

                      <div className="flex items-center justify-end gap-3 pt-2">
                        <button
                          type="submit"
                          disabled={isSubmittingFeed}
                          className="flex items-center gap-1.5 px-5 py-2.5 text-xs font-bold text-white bg-[#0F172A] hover:bg-slate-800 border border-slate-600 rounded-lg cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5 text-sky-400" />
                          <span>+ Add to Client Feeds</span>
                        </button>
                      </div>
                    </form>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {feeds.map((feed) => (
                      <div
                        key={feed.id}
                        className="bg-[#0e1320] border border-slate-800 rounded-xl p-3 flex items-center justify-between gap-3 shadow"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <img
                            src={feed.thumbnailUrl}
                            alt={feed.clientName}
                            referrerPolicy="no-referrer"
                            className="w-12 h-12 rounded-lg object-cover border border-slate-700 shrink-0"
                          />
                          <div className="min-w-0">
                            <h5 className="text-xs font-bold text-white truncate font-display">
                              {feed.clientName}
                            </h5>
                            <div className="text-[11px] font-mono text-sky-400 truncate">
                              {feed.instagramHandle}
                            </div>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleDeleteFeed(feed.id)}
                          aria-label={`Delete feed for ${feed.clientName}`}
                          className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded transition-colors cursor-pointer shrink-0"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 5: Leads CRM */}
              {activeTab === 'leads' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <h4 className="text-sm font-bold text-white font-display">
                        Incoming Inquiries from Booms.in
                      </h4>
                      <p className="text-xs text-slate-400">
                        Real inquiries captured from the website contact &amp; proposal forms
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={fetchLeads}
                      disabled={loadingLeads}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#0F172A] border border-slate-700 text-sky-400 rounded-lg hover:bg-slate-800 cursor-pointer"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${loadingLeads ? 'animate-spin' : ''}`} />
                      <span>Refresh Leads</span>
                    </button>
                  </div>

                  {leads.map((lead) => (
                    <div
                      key={lead.id}
                      className="bg-[#0e1320] border border-slate-800 rounded-xl p-4 transition-colors"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                        <div>
                          <span className="text-sm font-bold text-white font-display">
                            {lead.fullName}
                          </span>
                          {lead.companyName && (
                            <span className="text-xs text-slate-400 ml-2">
                              ({lead.companyName})
                            </span>
                          )}
                          <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                            Service: {lead.serviceType} · Budget: {lead.budgetRange}
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="text-[11px] text-slate-400 font-mono">Status:</span>
                          <select
                            value={lead.status}
                            onChange={(e) => handleUpdateLeadStatus(lead.id, e.target.value)}
                            className="bg-[#090d16] border border-slate-700 text-xs text-white rounded px-2.5 py-1 cursor-pointer"
                          >
                            <option value="new">New Inquiry</option>
                            <option value="contacted">Contacted</option>
                            <option value="proposal_sent">Proposal Sent</option>
                            <option value="closed">Closed Deal</option>
                          </select>
                        </div>
                      </div>

                      <p className="text-xs text-slate-300 bg-[#090d16] p-2.5 rounded-lg border border-slate-800/80 mb-3 italic">
                        "{lead.message}"
                      </p>

                      <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400 pt-2 border-t border-slate-800/80">
                        <div className="flex items-center gap-4">
                          <a
                            href={`tel:${lead.phone}`}
                            className="flex items-center gap-1.5 text-sky-400 hover:underline font-mono"
                          >
                            <Phone className="w-3.5 h-3.5" />
                            <span>{lead.phone}</span>
                          </a>
                          <a
                            href={`mailto:${lead.email}`}
                            className="flex items-center gap-1.5 text-slate-300 hover:text-white"
                          >
                            <Mail className="w-3.5 h-3.5" />
                            <span>{lead.email}</span>
                          </a>
                        </div>
                        <div className="flex items-center gap-1 text-[11px] font-mono text-slate-500">
                          <Calendar className="w-3 h-3" />
                          <span>{new Date(lead.createdAt).toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* TAB 6: Studio Analytics */}
              {activeTab === 'stats' && (
                <div className="space-y-6">
                  <div>
                    <h4 className="text-sm font-bold text-white font-display mb-1">
                      Booms Studio Telemetry &amp; Impact
                    </h4>
                    <p className="text-xs text-slate-400">
                      Aggregated cross-campaign metrics across commercial clients
                    </p>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div className="bg-[#0e1320] border border-slate-800 p-4 rounded-xl text-center">
                      <div className="text-2xl font-bold font-mono text-sky-400">
                        {stats?.totalImpressions || '124.6M+'}
                      </div>
                      <div className="text-xs text-slate-400 mt-1">Cross-Channel Views</div>
                    </div>

                    <div className="bg-[#0e1320] border border-slate-800 p-4 rounded-xl text-center">
                      <div className="text-2xl font-bold font-mono text-sky-400">
                        {stats?.averageRoas || '4.8x'}
                      </div>
                      <div className="text-xs text-slate-400 mt-1">Blended Client ROAS</div>
                    </div>

                    <div className="bg-[#0e1320] border border-slate-800 p-4 rounded-xl text-center">
                      <div className="text-2xl font-bold font-mono text-sky-400">
                        {crmClients.length}
                      </div>
                      <div className="text-xs text-slate-400 mt-1">Active CRM Accounts</div>
                    </div>

                    <div className="bg-[#0e1320] border border-slate-800 p-4 rounded-xl text-center">
                      <div className="text-2xl font-bold font-mono text-sky-400">
                        {projects.length}
                      </div>
                      <div className="text-xs text-slate-400 mt-1">3D Stage Projects Active</div>
                    </div>
                  </div>

                  <div className="bg-[#0e1320] border border-slate-800 p-5 rounded-xl space-y-3">
                    <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-sky-400">
                      <Film className="w-4 h-4" />
                      <span>Production Capabilities Summary</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-slate-300">
                      <div className="p-3 bg-[#090d16] rounded-lg border border-slate-800">
                        <span className="font-bold text-white block mb-1">
                          Studio 01: Bandra Soundstage
                        </span>
                        3,200 sq.ft acoustically treated studio with 24ft motorized lighting grid &amp; liquid rigs.
                      </div>
                      <div className="p-3 bg-[#090d16] rounded-lg border border-slate-800">
                        <span className="font-bold text-white block mb-1">
                          Studio 02: Andheri Creator Lab
                        </span>
                        Optimized for vertical 9:16 Instagram Reels, multi-cam podcasting &amp; live switching.
                      </div>
                      <div className="p-3 bg-[#090d16] rounded-lg border border-slate-800">
                        <span className="font-bold text-white block mb-1">
                          Studio 03: Lower Parel Suite
                        </span>
                        DaVinci Resolve Advanced Panel, DCI-P3 calibrated displays &amp; 7.1.4 Dolby Atmos mastering.
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
